<div class="col-lg-12">
    <div class="block">
        <div class="title"><strong>Server Navigation</strong></div>
        <div class="srvNavigation">
            <a id="l_server" href="/<?php echo $admDir; ?>/server?id=<?php echo $GET['id'] ?>">Server info</a>
            <a id="l_settings" href="/<?php echo $admDir; ?>/settings?id=<?php echo $GET['id'] ?>">Settings</a>
            <a id="l_web_ftp" href="/<?php echo $admDir; ?>/web_ftp?id=<?php echo $GET['id'] ?>">WebFTP</a>
            <a id="l_mods" href="/<?php echo $admDir; ?>/smods?id=<?php echo $GET['id'] ?>">Mods</a>
            <a id="l_plugins" href="/<?php echo $admDir; ?>/splugins?id=<?php echo $GET['id'] ?>">Plugins</a>
            <a id="l_maps" href="/<?php echo $admDir; ?>/smaps?id=<?php echo $GET['id'] ?>">Maps</a>
            <a id="l_console" href="/<?php echo $admDir; ?>/console?id=<?php echo $GET['id'] ?>">Console</a>
        </div>
    </div>
</div>