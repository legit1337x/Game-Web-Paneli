<!-- JavaScript files-->
<script src="/admin/vendor/jquery/jquery.min.js"></script>
<script src="/admin/vendor/popper.js/umd/popper.min.js"> </script>
<script src="/admin/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/admin/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/admin/vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="/admin/js/front.js"></script>
<script src="/admin/js/app.js?<?php echo time(); ?>"></script>
<script type="text/javascript" charset="utf-8" src="/assets/plugins/jquery-toast-plugin/dist/jquery.toast.min.js"></script>

<!--[SELECT2]-->
<script src="//cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script type="text/javascript" charset="utf-8" async defer>
	$(document).ready(function() {
		$('.js-example-basic-single').select2();
	});
</script>