<!-- JavaScript files-->
	<script src="/<?php echo $admDir; ?>/vendor/jquery/jquery.min.js"></script>
	<script src="/<?php echo $admDir; ?>/vendor/popper.js/umd/popper.min.js"> </script>
	<script src="/<?php echo $admDir; ?>/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/<?php echo $admDir; ?>/vendor/jquery.cookie/jquery.cookie.js"> </script>
	<script src="/<?php echo $admDir; ?>/vendor/chart.js/Chart.min.js"></script>
	<script src="/<?php echo $admDir; ?>/vendor/jquery-validation/jquery.validate.min.js"></script>
	<script src="/<?php echo $admDir; ?>/js/front.js"></script>