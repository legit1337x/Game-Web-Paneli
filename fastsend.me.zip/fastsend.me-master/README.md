# FastSend.me

A sponsor is sought to continue the project.

- [mskoko.me](https://github.com/mskoko) (mskoko.me@gmail.com) __(Developer)__
- [fastsend.me](http://fastsend.me) -- Not active


I own a domain if anyone has the will to mess with this let me know :)
