<?php
	define("DB_HOST", "localhost"); 	// MySQL Database Host
	define("DB_USER", "root");	// MySQL Username
	define("DB_PASS", "");  		// MySQL Password
	define("DB_NAME", "fast_send");  		// Database Name
?>