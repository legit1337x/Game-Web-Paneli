<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   file                 :  RS.php
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   author               :  -/-
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$lang = array();

/* Header - Navigacija */
$lang['nav_home'] 					= "Početna";
$lang['nav_about'] 					= "O nama";
$lang['nav_blog'] 					= "Blog";
$lang['nav_contact'] 				= "Kontakt";
$lang['nav_lang'] 					= "Jezik";

$lang['lang_rs'] 					= "Srpski";
$lang['lang_en'] 					= "Engleski";



/* 
* HOME PAGE
*/

?>