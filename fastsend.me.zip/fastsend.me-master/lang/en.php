<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   file                 :  EN.php
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   author               :  -/-
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

$lang = array();

$lang['nav_home'] 			= "Home";
$lang['nav_about'] 			= "About us";
$lang['nav_blog'] 			= "Blog";
$lang['nav_contact'] 		= "Contact";
$lang['nav_lang'] 			= "Language";

$lang['lang_rs'] 			= "Serbian";
$lang['lang_en'] 			= "English";


/* 
* HOME PAGE
*/

?>