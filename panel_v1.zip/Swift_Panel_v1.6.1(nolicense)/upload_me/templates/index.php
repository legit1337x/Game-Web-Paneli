<?php //004d4
// WARNING: This script is protected. Any attempt to reverse engineer, debug or de-code this file or its dependent files is strictly prohibited.
// @package SWIFT Panel Version 1.6.1
// @Copyright (C) 2008-2009 SWIFT Panel All rights reserved
// @link http://www.swiftpanel.com
// @date 2010-8-14
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');@dl($__ln);if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5DES951eU9rdSIQnSy0MevD6FQMppmJSUOYyAhWmtkmeEyuAozZ8T9wrLm5cnvPd3kvDWmlL
l1AT6NkvDgE+9qyIOLCl/qoZaPJkxLRnKXm7beLpS9t1EaYL6NR9GHheRrs8kUimpvb/vpj/RWjA
j40iL/a8Xbd7yY8D35nBiQDL+zW0KayFbPD8fKU0QiMqC8Pxfjcv5bJgDo9TqEEQAO32r/XXfE32
bbAIAnWQvEKEI16nLevvGhmlRZzFLXHWUMjjMuhgt2xaUq7u0LCZcsmJMT8H8XwNPEH4QcljnpIo
ZxzscCeOJqdDeV0J08DGSxXuI86HOXUMEFMc+pBhMnkwGVWvaEW21ltr8x6xCL8jGejbLOpW0dtJ
+h1zxlADGWQMxrwEhm/qmEm3zLRdbdFbZrW4HIWfvYCjmdfHVGFspcescNPiauc1Pe5j9iI556XT
Ro56Bm7V96hSKBuR7wmdjAoy7CbBlhLmAcdn8kABeeZqLvqfJC3WzQVTIBWV