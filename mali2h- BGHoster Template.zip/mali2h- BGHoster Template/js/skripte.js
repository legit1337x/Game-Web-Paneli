﻿$(document).ready(function(){
	$("#igra").change(function(){
		var igra=$("#igra").val();
		if(igra=="cs"){
			$("#naruci_cs").addClass("vidljivost");
			$("#naruci_sa").removeClass("vidljivost");
			$("#naruci_cod4").removeClass("vidljivost");
		}
		if(igra=="sa"){
			$("#naruci_sa").addClass("vidljivost");
			$("#naruci_cs").removeClass("vidljivost");
			$("#naruci_cod4").removeClass("vidljivost");
		}
		if(igra=="cod4"){
			$("#naruci_cod4").addClass("vidljivost");
			$("#naruci_cs").removeClass("vidljivost");
			$("#naruci_sa").removeClass("vidljivost");
		}
		
		if(igra=="0"){
			$("#naruci_cs").removeClass("vidljivost");
			$("#naruci_sa").removeClass("vidljivost");
			$("#naruci_cod4").removeClass("vidljivost");
		}
		
	});
	

})

/* cena za counter-strike 1.6 */
	 
$(document).ready(function(){
	var cena=0;
	var formaSlot=0;
	var ukupno=0;
	var valuta="";
	$(".drzava_cs").change(function(){
	
		var drzava=$(".drzava_cs option:selected").val();
		if(drzava=="Srbija"){
			
			cena=25;
			valuta="rsd";
		}
		if(drzava=="Hrvatska"){
			
			cena=0.25;
			valuta="€";
		}
		if(drzava=="Bosna"){
			
			cena=0.5;
			valuta="KM";
		}
		if(drzava=="Crna Gora"){
			
			cena=0.25;
			valuta="€";
		}
		ukupno=0;
		ukupno=formaSlot*cena;
		$("#cena").val(Math.ceil(ukupno)+" "+valuta);
	});
	$(".slot_cs").change(function(){
	formaSlot=$(".slot_cs option:selected").val();
		ukupno=0;
		ukupno=formaSlot*cena;
		$("#cena").val(Math.ceil(ukupno)+" "+valuta);
	
	
	
	
	});
	
	
});
	 
/* cena za gta san andreas mp */
	 
$(document).ready(function(){
	var cena=0;
	var formaSlot=0;
	var ukupno=0;
	var valuta="";
	$(".drzava_sa").change(function(){
	
		var drzava=$(".drzava_sa option:selected").val();
		if(drzava=="Srbija"){
			
			cena=7;
			valuta="rsd";
		}
		if(drzava=="Hrvatska"){
			
			cena=0.07;
			valuta="€";
		}
		if(drzava=="Bosna"){
			
			cena=0.10;
			valuta="KM";
		}
		if(drzava=="Crna Gora"){
			
			cena=0.07;
			valuta="€";
		}
		ukupno=0;
		ukupno=formaSlot*cena;
		$("#cena").val(Math.ceil(ukupno)+" "+valuta);
	});
	$(".slot_sa").change(function(){
	formaSlot=$(".slot_sa option:selected").val();
		ukupno=0;
		ukupno=formaSlot*cena;
		$("#cena").val(Math.ceil(ukupno)+" "+valuta);
	
	
	
	
	});
	
	
});

/* cena za call of duty 4 mp */
	 
$(document).ready(function(){
	var cena=0;
	var formaSlot=0;
	var ukupno=0;
	var valuta="";
	$(".drzava_cod4").change(function(){
	
		var drzava=$(".drzava_cod4 option:selected").val();
		if(drzava=="Srbija"){
			valuta="rsd";
			cena=30;
		}
		if(drzava=="Hrvatska"){
			valuta="€";
			cena=0.3;
		}
		if(drzava=="Bosna"){
			valuta="€";
			cena=0.3;
		}
		if(drzava=="Crna Gora"){
			valuta="€";
			cena=0.3;
		}
		ukupno=0;
		ukupno=formaSlot*cena;
		$("#cena").val(Math.ceil(ukupno)+" "+valuta);
	});
	$(".slot_cod4").change(function(){
	formaSlot=$(".slot_cod4 option:selected").val();
		ukupno=0;
		ukupno=formaSlot*cena;
		$("#cena").val(Math.ceil(ukupno)+" "+valuta);
	
	
	
	
	});
	
	
});


var greske = false;
			
	function ispisGreske(obj)
	{
		$(obj).addClass('greska');
	
		greske=true;
		
		$(obj).next('.opis_greske').show().text("Ovde je doslo do greske!");
	}
/* provera forme za narucivanje1 ( biranje igre ) */	
	$(document).ready(function(){	
		$("#btnNaruci1").click(function(){
			
			greske=false;
			var formaIgra=$("#igra option:selected").val();
			 $('input').removeClass('greska');
			 $('select').removeClass('greska');
			 $("#uslovi").parent().removeClass('greska_uslovi');
			 $('.opis_greske').hide();
			
			
			if(formaIgra==null || formaIgra=="0"){
		      ispisGreske("#igra");
		   }
		   
		   if(greske)
		{
			
			jNotify(
					'Izaberite igru!',
					{
					  autoHide : false, // added in v2.0
					  clickOverlay : true,
					  VerticalPosition : 'top',
					  HorizontalPosition : 'center',
					  ShowOverlay : true,
					  ColorOverlay : '#000',
					  OpacityOverlay : 0.8,
					  onClosed : function(){
						
					  }
					  
				  }
				  );
			
		}else{
		document.form.submit();
		}
		});
	 });
	
/* provera forme za narucivanje */	
	$(document).ready(function(){
	
	  $("#btnNaruci").click(function(){
		
	     greske=false;
		 var formaDrzava=$("#drzava option:selected").val();
		 var formaMod=$("#mod option:selected").val();
		 var formaSlot=$("#slot option:selected").val();
		  $('input').removeClass('greska');
		  $('select').removeClass('greska');
		  $("#uslovi").parent().removeClass('greska_uslovi');
		  $('.opis_greske').hide();
		
		var reIme = /^[A-Z]{1}[a-z]{2,19}$/;
		
		var reEmail = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		
		
		
		
		
		if(formaDrzava==null || formaDrzava=="0"){
		      ispisGreske("#drzava");
		   }
		if(formaMod==null || formaMod=="0"){
		      ispisGreske("#mod");
		   }
		if(formaSlot==null || formaSlot=="0"){
		      ispisGreske("#slot");
		   }
		if($("[name='uslovi']:checked").length==0){
		      
			  $("#uslovi").parent().addClass('greska_uslovi');
		   }
		if(!greske)
		{
			
			jNotify(
					'Pozdrav, uspesno ste narucili svoj Server! Bice vam odgovoreno u najkracem roku. Obavezno posetite vas E-mail, kako bi videli podatke o uplati.',
					{
					  autoHide : false, // added in v2.0
					  clickOverlay : true,
					  VerticalPosition : 'top',
					  HorizontalPosition : 'center',
					  ShowOverlay : true,
					  ColorOverlay : '#000',
					  OpacityOverlay : 0.8,
					  onClosed : function(){
						document.form.submit();
					  }
					  
				  }
				  );
			
		}
		
		
	  });
	 });



/* provera polja za kontakt formu */

	 $(document).ready(function(){
	
	  $("#btnKontakt").click(function(){
	     greske=false;
	     var formaIme=$("#ime").val();
		 var formaEmail=$("#e-mail").val();
		 var formaKomentar=$("#komentar").val();
		 
		  $('input').removeClass('greska');
		  $('textarea').removeClass('greska');
		  $('select').removeClass('greska');
		  $(".igra").parent().removeClass('greska_uslovi');
		  $('.opis_greske').hide();
		  $('#file_greska').hide();
		
		var reIme = /^[A-Z]{1}[a-z]{2,19}$/;
		
		var reEmail = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		
		
		
		if(formaEmail=="")
		{
			
			ispisGreske('#e-mail');
		}
		
		if(formaIme=="")
		{
			ispisGreske('#ime');
		}
		if(!reEmail.test(formaEmail))
		{
			ispisGreske('#e-mail');
		}
		if(formaKomentar=="")
		{
			ispisGreske('#komentar');
		}
		
		if(!greske)
		{
			
			jNotify(
					'Uspesno ste poslali poruku!',
					{
					  autoHide : false, // added in v2.0
					  clickOverlay : true,
					  VerticalPosition : 'top',
					  HorizontalPosition : 'center',
					  ShowOverlay : true,
					  ColorOverlay : '#000',
					  OpacityOverlay : 0.8,
					  onClosed : function(){
						document.form.submit();
					  }
					  
				  }
				  );
			
			
			
			
		}
		
	  });
	 });
	 
/* provera polja za potvrdi formu */

	 $(document).ready(function(){
	
	  $("#btnPotvrdi").click(function(){
	     greske=false;
		 var formaKomentar=$("#komentar").val();
		 var formaUplatnica=$("#uplatnica").val();
		 
		  $('input').removeClass('greska');
		  $('textarea').removeClass('greska');
		  $('select').removeClass('greska');
		  $(".igra").parent().removeClass('greska_uslovi');
		  $('.opis_greske').hide();
		  
		
		if(formaKomentar=="")
		{
			ispisGreske('#komentar');
		}
		if(formaUplatnica=="")
		{
			ispisGreske('#uplatnica');
		}
		
		if(!greske)
		{
			
			jNotify(
					'Uspesno ste poslali sliku uplatnice!',
					{
					  autoHide : false, // added in v2.0
					  clickOverlay : true,
					  VerticalPosition : 'top',
					  HorizontalPosition : 'center',
					  ShowOverlay : true,
					  ColorOverlay : '#000',
					  OpacityOverlay : 0.8,
					  onClosed : function(){
						document.form.submit();
					  }
					  
				  }
				  );
			
			
			
			
		}
		
	  });
	 });
	 


/* provera polja za registraciju */

 $(document).ready(function(){
	
	  $("#btnReg").click(function(){
	     greske=false;
		 var formaIme=$("#Ime").val();
		 var formaPrezime=$("#Prezime").val();
		 var formaEmail=$("#email").val();
		 var formaLozinka1=$("#lozinka").val();
		 var formaLozinka2=$("#lozinka2").val();
		/* var formaFile=$("#file").val(); */
		 var captcha=$("#captcha").val();
		 
		  $('input').removeClass('greska');
		  $('select').removeClass('greska');
		  $(".igra").parent().removeClass('greska_uslovi');
		  $('.opis_greske').hide();
		  $('#file_greska').hide();
		
		var reIme = /^[A-Z]{1}[a-z]{2,19}$/;
		
		var reEmail = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		
		if(captcha=="")
		{
			ispisGreske('#captcha');
		}
		if(captcha!="5")
		{
			ispisGreske('#captcha');
		}
		
		
		if(formaIme=="")
		{
			ispisGreske('#Ime');
		}
		
		if(formaPrezime=="")
		{
			
			ispisGreske('#Prezime');
		}
		
		if(formaEmail=="")
		{
			
			ispisGreske('#email');
		}
		if(!reEmail.test(formaEmail))
		{
			ispisGreske('#email');
		}
		if(formaLozinka1=="")
		{
			ispisGreske('#lozinka');
		}
		if(formaLozinka2=="")
		{
			ispisGreske('#lozinka2');
		}
		/* if(formaFile=="")
		{
			ispisGreske('#file');
		} */
		if(!formaLozinka1==formaLozinka2)
		{
			ispisGreske('#lozinka2');
		}
		
		if(!greske)
		{
			
						
						document.regform.submit();
					  
			
			
		}
		
	  });
	 });


/* ajax narucivanje 

var httpObj=null;

function kreiranje(){
	if(window.ActiveXObject)
		return new ActiveXObject("Microsoft.XMLHTTP");
	else if(window.XMLHttpRequest)
		return new XMLHttpRequest();
		else{
			alert("Vas browser ne podrzava AJAX!");
			return null;
		}
}

function rezultat(){
	if(httpObj.readyState==4){
		var rezultat=document.getElementById("rezultat");
		rezultat.value=httpObj.responseText;
	}
}

function obradi(){
	httpObj=kreiranje();
	if(httpObj!=null){
		var igra=document.getElementById('igra');
		httpObj.open("GET",naruci_obrada.php?igra="+igra.value,true);
		http.Obj.send(null);
		httpObj.onreadystatechange=rezultat;
	}
}

*/






















