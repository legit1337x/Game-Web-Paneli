<!DOCTYPE html>

<head>

<title>GB Hoster | GameServer Hosting Template by Djoxi</title>

<meta charset="utf-8">    

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="icon" href="img/if_fav.ico" type="image/if_fav">

<meta name="author" content="Djordje Radovanovic Djoxi | www.djoxi.com">



<link rel="stylesheet" href="css/bootstrap.css" >

<link rel="stylesheet" href="css/style.css">

	<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>

		<script src="../../ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js" type="text/javascript"></script>

		<script src="js/skripte.js" type="text/javascript"></script>

		<link rel="stylesheet" href="nivo-slider/themes/default/default.css" type="text/css" media="screen" />

		<link rel="stylesheet" href="nivo-slider/themes/bar/bar.css" type="text/css" media="screen" />

		<link rel="stylesheet" href="nivo-slider/themes/light/light.css" type="text/css" media="screen" />

		<link rel="stylesheet" href="nivo-slider/nivo-slider.css" type="text/css" media="screen" />

		<link rel="stylesheet" type="text/css" href="jNotify/jNotify.jquery.css" media="screen" />

		<link rel="stylesheet" type="text/css" href="jNotify/jNotify.jquery.css" media="screen" />

		<link rel="stylesheet" type="text/css" href="jNotify/jNotify.jquery.css" media="screen" />

		<script type="text/javascript" src="jNotify/jquery.js"></script>

		<script type="text/javascript" src="jNotify/jNotify.jquery.js"></script>

		<script src="nivo-slider/jquery.nivo.slider.pack.js" type="text/javascript"></script>





</head>

<body>

<div class="top_bar">

</div>



<div class="container"> 

	<div id="logo_nav_row">

		<div style="width:40%;" id="logo">

			<a href="index.php">

				<img src="img/logo.png">

			</a>



		<div id="login">



						

						<form action="http://vashosting.com/gpanel" method="post">

							<input type="hidden" name="task" value="login" />

							<input type="hidden" name="return" value="" />

							

							<div id="provera_unos">

								<h3>Login Panel </h3>

							<img src="img/input_user.png"><input id="username" type="text" name="email" class="text" value="e-mail" onblur="if (this.value == '') {this.value = 'e-mail';}" onfocus="if (this.value == 'e-mail') {this.value = '';}"/><br></i>

							<img src="img/input_user.png"><input id="pass"type="password" name="password" class="text" value="password" onblur="if (this.value == '') {this.value = 'password';}" onfocus="if (this.value == 'password') {this.value = '';}"/><br></i>

							</div>

							<div id="logiranje"><input type="submit" value="LOGIN!" class="login_btn" /></div>

						</form>

					</div>		

					</div>









		</div>

		<div id="omot">		

		<div id="navdjoxi"></div>

		<div id="pod_nav"></div>

		<div id="navigacija">

		<div class="drzac">

			<div class="nav">

			<a href="index.php" class="active"><b>FILIMI</a>

			<a href="#">GPANEL</a>

			<a href="order_cs.php">POROSIT</a>

			<a href="gametracker.php">GAMETRACKER</a>

			<a href="#">FORUM</a>			

			<a href="https://www.instagram.com/ermalmehmeti2/">KONTAKT</a>					

			</div>

 			</div>



				<div class="slider-wrapper theme-default">

					<div id="slider" class="nivoSlider">



                    <img src="slike/slide1.png" alt="" />

                    <img src="slike/slide2.png" alt="" />

					</div>

				</div>



<script type="text/javascript">

				$(window).load(function() {

					$('#slider').nivoSlider({

					effect: 'boxRandom',

					controlNav: false,

					 randomStart: true,

					});

					

				});



</script>	



		<div id="obavestenja">



			<span class="obavestenja">Server Status:</span>

			<span class="obavestenje1"><b>faqe e re!</b><br>Te nderuar,<br>Ne ju informoj se ne jemi duke punuar leshuar versionin e fundit te faqes v2! Ne shpresojme qe ju pelqen dizajn te ri! Kjo faqe eshte aktualisht ne beta! <b></b></br></span>





		</div>



		<div id="sponzori">



			<span class="sponzor1"><img src="img/sponzori/1.png"></i></span>

			<span class="sponzor2"><img src="img/sponzori/2.png"></i></span>

			<span class="sponzor3"><img src="img/sponzori/3.png"></i></span>	

			<span class="sponzor4"><img src="img/sponzori/4.png"></i></span>			



		</div>



		<div id="igre">



			<span class="igra1">

				<span class="box_slika"><img src="img/cs.png"></i></span>

				<span class="igra1_info"><naslov>Counter Strike 1.6</naslov>

				<info>Location: Germany<br>Ping:20-50ms/s<br>Qmimi:0.5cent/slot!</info></span>

				<div id="button">

				<a href="order_cs.php"><button>Porosit</button></a>

				</div>

			</span>



			<span class="igra2">

				<span class="box_slika"><img src="img/samp.png"></i></span>

				<span class="igra2_info"><naslov>GTA SA:MP</naslov>

				<info>Location: Germany<br>Ping:10-50ms/s<br>Qmimi:0.5cent/slot!</info></span>

				<div id="button">

				<a href="order_samp.php"><button>Porosit</button></a>

				</div>

			</span>



			<span class="igra3">

				<span class="box_slika"><img src="img/cod.png"></i></span>

				<span class="igra3_info"><naslov>Call of Duty</naslov>

				<info>Location: Germany<br>Ping:20-50ms/s<br>Qmimi:0.5cent/slot!</info></span>

				<div id="button">

				<a href="order_cod.php"><button>Porosit</button></a>

				</div>

			</span>			

		</div>





		<div id="novosti">


 <!-- Begin BidVertiser code -->
<SCRIPT data-cfasync="false" SRC="//bdv.bidvertiser.com/BidVertiser.dbm?pid=626918&bid=1722951" TYPE="text/javascript"></SCRIPT>
<!-- End BidVertiser code --> 
			

			<div id="statiske">



				<span class="statiske">Statiska e Hostingit:</span>



				<span class="reg_serveri"><serveri>server regjistruar:</serveri><rez>0</rez>

				<span class="statiska_linija_serveri"></span>

				</span>

				<span class="reg_klijenta"><klijenti>konsumatoreve regjistruar:</klijenti><rez>20</rez>

				<span class="statiska_linija_klijenti"></span>

				</span>

				<span class="reg_dedictated"><ded>Dedicated Server:</ded><rez>4</rez>

				<span class="statiska_linija_dedictated"></span>

				</span>



				<div class="obavestenje_stats">*Kjo eshte e sakte statisk GB Hosting! Statsika eshte perditesuar cdo muaj!</div>

			</div>



			<div class="onama"><h1>Qfare ju duhet te dini ......</h1>

				<br>Duhet te dini nese ju vjedhin serveri at her na nuk ju sigrujom per ta edhe nese ju i ndrroni addonsa te webit ton at her nalet direkt server edhe nese e ndryshoni gamename te hosti ton nale serveri flm per mirkuptim...</br>

			</div>

		</div>



		<div id="linkovi">




			<span class="linkovi"><br>

			<a href="index.php">Fillimi</a></br>

			<a href="#">GPANEL</a></br>

			<a href="order_cs.php">Porosit</a></br>

			<a href="gametracker.php">GAMETRACKER</a></br>

			<a href="#">FORUM</a></br>

			<a href="https://www.instagram.com/ermalmehmeti2/">KONTAKT</a></br>

			</span>



			<span class="kontakt">KONTAKT<br>

			<a>www.fb.com/ermal.mehmetii</a></br>

			<a>instagram.com/ermalmehmeti2</a></br>

			<a>www.a24h-gaming.com</a></br>

			</span>

		</div>



<br clear="all">

	<footer>

	&copy; Copyright 2014/2015 GB Hoster <br>Design & Coded: <a href="https://www.facebook.com/ermal.mehmetii?fref=ts">Ermal Mehmeti</a></br>

	</footer>

</div>

</body>

</html>
