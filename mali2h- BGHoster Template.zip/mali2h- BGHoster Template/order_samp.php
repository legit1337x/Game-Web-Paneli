<?php
if(isset($_POST['submit'])){
	/* INFO KORISNIKA */
	$name = $_POST['name'];
	$email = $_POST['email'];
	$grad = $_POST['grad'];
	$drzava = $_POST['drzava'];

	/* INFO O SERVERU */
	$naziv_servera = $_POST['naziv_servera'];
	$igra = $_POST['igra'];
	$mod = $_POST['mod'];
	$slotovi = $_POST['slotovi'];	
	if(($name == '') || ($email == '') || ($drzava == '') || ($grad == '') || ($naziv_servera == '') || ($igra == 'SanAndreas MultiPlayer') || ($mod == '') || ($slotovi == '') ){
	}
	
	else {
		$ToEmail = 'vasmail@mail.com';  // VAS E-MAIL
		$EmailSubject = 'Nova narudzbina'; 
		$mailheader = "From: ".$_POST["email"]."\r\n"; 
		$mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
		$mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
		$MESSAGE_BODY = "Ime i prezime: \r\n ".$_POST["name"]." <br> "; 
		$MESSAGE_BODY .= "Email: \r\n ".$_POST["email"]." <br> "; 
		$MESSAGE_BODY .= "Grad: \r\n ".$_POST["grad"]." <br> "; 
		$MESSAGE_BODY .= "Drzava: \r\n ".$_POST["drzava"]." <br> "; 
		$MESSAGE_BODY = "Naziv Servera: \r\n ".$_POST["naziv_servera"]." <br> "; 
		$MESSAGE_BODY .= "Igra: \r\n ".$_POST["igra"]." <br> "; 
		$MESSAGE_BODY .= "Mod: \r\n ".$_POST["mod"]." <br> "; 
		$MESSAGE_BODY .= "Slotovi: \r\n ".$_POST["slotovi"]." <br> "; 				
		mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader);

	}
}
?>
<!DOCTYPE html>
<head>
<title>GB Hoster | GameServer Hosting Template by Djoxi</title>
<meta charset="utf-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="img/if_fav.ico" type="image/if_fav">
<meta name="author" content="Djordje Radovanovic Djoxi | www.djoxi.com">

<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="stylesheet" href="css/style.css">
	<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
		<script src="../../ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js" type="text/javascript"></script>
		<script src="js/skripte.js" type="text/javascript"></script>
		<link rel="stylesheet" href="nivo-slider/themes/default/default.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="nivo-slider/themes/bar/bar.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="nivo-slider/themes/light/light.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="nivo-slider/nivo-slider.css" type="text/css" media="screen" />
		<link rel="stylesheet" type="text/css" href="jNotify/jNotify.jquery.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="jNotify/jNotify.jquery.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="jNotify/jNotify.jquery.css" media="screen" />
		<script type="text/javascript" src="jNotify/jquery.js"></script>
		<script type="text/javascript" src="jNotify/jNotify.jquery.js"></script>
		<script src="nivo-slider/jquery.nivo.slider.pack.js" type="text/javascript"></script>


</head>
<body>
<div class="top_bar">
</div>

<div class="container"> 
	<div id="logo_nav_row">
		<div style="width:40%;" id="logo">
			<a href="index.php">
				<img src="img/logo.png">
			</a>

		<div id="login">

						
						<form action="http://vashosting.com/gpanel" method="post">
							<input type="hidden" name="task" value="login" />
							<input type="hidden" name="return" value="" />
							
							<div id="provera_unos">
								<h3>Login Panel </h3>
							<img src="img/input_user.png"><input id="username" type="text" name="email" class="text" value="e-mail" onblur="if (this.value == '') {this.value = 'e-mail';}" onfocus="if (this.value == 'e-mail') {this.value = '';}"/><br></i>
							<img src="img/input_user.png"><input id="pass"type="password" name="password" class="text" value="password" onblur="if (this.value == '') {this.value = 'password';}" onfocus="if (this.value == 'password') {this.value = '';}"/><br></i>
							</div>
							<div id="logiranje"><input type="submit" value="LOGIN!" class="login_btn" /></div>
						</form>
					</div>		
					</div>




		</div>
		<div id="omot">		
		<div id="navdjoxi"></div>
		<div id="pod_nav"></div>
		<div id="navigacija">
		<div class="drzac">
			<div class="nav">
			<a href="index.php"><b>HOME</a>
			<a href="#">GPANEL</a>
			<a href="order_cs.php" class="active">NARUCI</a>
			<a href="gametracker.php">GAMETRACKER</a>
			<a href="#">FORUM</a>			
			<a href="contact.php">KONTAKT</a>					
			</div>
 			</div>


 			<div id="order">
 				<span class="order_slika"><img src="img/samp.png" style="width:170px;"></i></span>
				<span class="order_title">Narucivanje novog servera</span>
				<br><br>
				

				<div class="games_side">
					<div class="order_box">
						<span class="info_klijent">Informacije o korisniku:</span>
						<form action="order_samp.php" method="POST">
						<input name="name" placeholder="Ime i Prezime" /><br>
						<input name="email" placeholder="E-mail" /><br>
						<input name="grad" placeholder="Grad" /><br />
						<input name="drzava" placeholder="Drzava" /><br />		

					<div id="info_server">
						<span class="info_server">Informacije o serveru:</span>
						<form action="order_cs.php" method="POST">
						<input name="naziv_servera" placeholder="Naziv Servera" /><br>
						<input name="igra" value="SanAndreas MultiPlayer" readonly  /><br>
						<select name="mod">
						  <option value="public">Public (Defaulth)</option>
						</select>
						<select name="slotovi">
						  <option value="25 slotova">25 slotova</option>
						  <option value="75 slotova">75 slotova</option>
						  <option value="100 slotova">100 slotova</option>
						  <option value="200 slotova">200 slotova</option>						  					  
						</select>
					</div>
						<button class="send" name="submit">NARUCI</button></a>
						</form>
					</div>

 			</div>


		<div id="novosti2">

			<span class="novosti">NOVOSTI:</span>

			<span class="novost1">
			<h1>Novi Sajt!</h1>
			<opis>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrudexercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute </opis>
			<span class="vise"><a href="novost1.php">POGLEDAJ VISE!</a></span>
			</span>

			<span class="novost2">
			<h1>Novi Sajt!</h1>
			<opis>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrudexercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute </opis>
			<span class="vise"><a href="novost2.php">POGLEDAJ VISE!</a></span>
			</span>

			<span class="novost3">
			<h1>Novi Sajt!</h1>
			<opis>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrudexercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute </opis>
			<span class="vise"><a href="novost3.php">POGLEDAJ VISE!</a></span>
			</span>

			<span class="novost4">
			<h1>Novi Sajt!</h1>
			<opis>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrudexercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute </opis>
			<span class="vise"><a href="novost4.php">POGLEDAJ VISE!</a></span>
			</span>

			<div id="statiske">

				<span class="statiske">Statiske Hostinga:</span>

				<span class="reg_serveri"><serveri>Registrovanih servera:</serveri><rez>20</rez>
				<span class="statiska_linija_serveri"></span>
				</span>
				<span class="reg_klijenta"><klijenti>Registrovanih klijenta:</klijenti><rez>20</rez>
				<span class="statiska_linija_klijenti"></span>
				</span>
				<span class="reg_dedictated"><ded>Dedictated Servera:</ded><rez>4</rez>
				<span class="statiska_linija_dedictated"></span>
				</span>

				<div class="obavestenje_stats">*Ovo je tacna statiska GB Hostinga! Statsika se azurira svakog meseca!</div>
			</div>

			<div class="onama"><h1>Ono sto bi trebalo da znate...</h1>
				<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt...</br>
			</div>
		</div>

		<div id="linkovi">

			<span class="linkovi">LINKOVI<br>
			<a href="index.php">HOME</a></br>
			<a href="#">GPANEL</a></br>
			<a href="order_cs.php">NARUCI</a></br>
			<a href="gametracker.php">GAMETRACKER</a></br>
			<a href="#">FORUM</a></br>
			<a href="contact.php">KONTAKT</a></br>
			</span>

			<span class="kontakt">KONTAKT<br>
			<a>info@gbhosting.rs</a></br>
			<a>support@gbhosting.rs</a></br>
			<a>djordje@djoxi.com</a></br>
			</span>
		</div>

<br clear="all">
	<footer>
	&copy; Copyright 2014/2015 GB Hoster <br>Design & Coded: <a href="https://www.facebook.com/djordje.radovanovic3?fref=ts">Djordje Radovanovic Djoxi</a></br>
	</footer>
</div>
</body>
</html>