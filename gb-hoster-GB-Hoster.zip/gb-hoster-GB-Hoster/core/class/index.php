<?php

header('HTTP/1.0 403 Forbidden');

?>