<script src="/admin/assets/js/excanvas.min.js"></script> 
<script src="/admin/assets/js/base.js"></script> 


<!-- <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>-->
<script type="text/javascript" src="/admin/assets/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>