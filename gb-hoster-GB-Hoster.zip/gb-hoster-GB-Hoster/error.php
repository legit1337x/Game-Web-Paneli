<!DOCTYPE html>
<html>
<head>

	<title>404 Error - Nepostojeca stranica!</title>

	<style type="text/css">

		body {
			font-family: Arial;
			font-size: 12px;
			color: orangered;	
		}

		#Error {
			margin-top: 80px;
		}

		.errorSajt {
			text-align: center;
		}

		.errorSajt a {
			color: #009cff; 
			text-decoration: none; 
			font-weight: bold;
			font-size: 15px;
		}

	</style>

</head>

<body style="background-color: black;">

	<div id="Error">
		
		<h1 style="text-align: center; font-weight: bold;">ERROR 404</h1>

		<h3 style="text-align: center; font-weight: bold;">Stranica koju trazite ne postoji!</h3>

	</div>

</body>
</html>