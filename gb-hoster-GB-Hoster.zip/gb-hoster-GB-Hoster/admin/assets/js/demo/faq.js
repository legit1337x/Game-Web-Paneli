$(function () {
	
	$('.faq-list').goFaq ();

});