<?php ### RENAME TO: configuration.php ###
//====================================================================
//  Copyright © 2008 SWIFT Panel All Rights Reserved.
//====================================================================

//*************************************************************************************************

	### REQUIRED SETTINGS ###
	
	// DO NOT CHANGE
	define('LICENSE', 'IgnoreMe');
    // DO NOT CHANGE  
	
	// DBHOST is the MySQL Database Hostname
	// Default: "localhost"
	define('DBHOST', 'localhost');
	
	// DBNAME is the MySQL Database Name
	define('DBNAME', 'swiftpanel');
	
	// DBUSER is the MySQL Database Username
	define('DBUSER', 'swiftpanel');
	
	// DBPASSWORD is the MySQL Database Password
	define('DBPASSWORD', 'gpanel1');

//*************************************************************************************************

//====================================================================
//  Copyright © 2008 SWIFT Panel All Rights Reserved.
//====================================================================
?>
