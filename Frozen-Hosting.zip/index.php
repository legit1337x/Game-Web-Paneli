<!doctype html>
<head>
    <meta charset="UTF-8" />
    <title>Alien Hosting</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="Demir Izdirovic morphe_uS@live.com">
	
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="img/favicon.ico">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
<script type="text/javascript" src="http://malsup.github.com/chili-1.7.pack.js"></script>
<script type="text/javascript" src="http://malsup.github.com/jquery.cycle.all.js"></script>
<script type="text/javascript">
$(function() {
    $('#slideshow').cycle({
        speed:       200,
        timeout:     3000,
        pager:      '#nav',
        pagerEvent: 'mouseover',
		prev: '#prev',
        next: '#next',
		pauseOnPagerHover: true

    });
});
</script>

</head>

<div class="top">
<div class="top-width">Dobrodosli na <span class="blue">Alien Hosting</span> . Uzivajte!</div>
</div>

<div id="content">

<div class="login">
<div class="login_header">LOGIN FORM</div> <br /> 

<center>
<!-- Login forma -->
<form action="" method="POST">
<span class="in_img"><img src="img/login-u.png"></span> <input type="text" name="username" placeholder="Username" required="required"> <br /><div class="space"></div>
<span class="in_img"><img src="img/login-p.png"></span> <input type="password" name="password" placeholder="Password" required="required"> <br /><div class="space"></div>
<button class="button">Login</button> 

<br /><br />

<a href="">Zaboravljena sifra?</a> 
</form>
</center>

</div>

<!-- logo -->
<div class="logo">
 <a href="index.php"><img src="img/logo_test.png"></a>
</div>

</div>

<!-- Content2 -->
<div id="content_2">

<!-- Nav -->
<div class="nave">
<ul>
 <li><a href="">Pocetna</a></li>
 <li><a href="">Naruci server</a></li>
 <li><a href="">GamePanel</a></li>
 <li><a href="">Forum</a></li>
 <li><a href="">Kontakt</a></li>
</ul>
</div>

<!-- Slider -->
<table cellspacing="20"><tr> 
    <td>    
	    <center><div id="nav"></div></center>
		
	<div id="controls">
        <a id="prev" href="#">&lt;</a>
        <a id="next" href="#">&gt;</a>
    </div>
		
        <div id="slideshow" class="pics">
            <img src="http://www.foxdemon.com/wp-content/uploads/2013/04/Home_02-920x250.png" width="920" height="250" />
            <img src="http://www.xstore.cl/image/cache/data/gta5banner-950x250.png" width="920" height="250" />
            <img src="http://www.xstore.cl/image/cache/data/codghost-950x250.png" width="920" height="250" />
            <img src="http://www.xstore.cl/image/cache/data/bf4-950x250.png" width="920" height="250" />
        </div>
    </td></tr>
    </table>
	
 <!-- Why -->
 <div class="why"><a href="">ZASTO IZABRATI NAS?</a></div>
 
  <!-- Games -->
   <div class="right">
  
  
    <!-- CS GO -->
    <div class="gamebg">
  
    <p>Premium lokacija Srbija,<br />ping 5-20 od 8.4 eur<br />Lite lokacija Nemacka,<br />ping 45-50 od 4.2 eur <br /><br /> <a href=""><button class="button">NARUCI</button></a> </p>
    <img src="http://www.kgb-hosting.com/pictures/csgobox.jpg">

    </div>
	
	<br /><div class="space"></div>
  
  <!-- Samp -->
  <div class="gamebg">
  
    <p>Premium lokacija Srbija,<br />ping 5-20 od 8.4 eur<br />Lite lokacija Nemacka,<br />ping 45-50 od 2 eur <br /><br /> <a href=""><button class="button">NARUCI</button></a> </p>
    <img src="http://www.kgb-hosting.com/pictures/cod.jpg">

  </div>
  
  <br /><div class="space"></div>
  
  <!-- MC -->
  <div class="gamebg">
  
    <p>Premium lokacija Srbija,<br />ping 5-20 od 8.4 eur<br />Lite lokacija Nemacka,<br />ping 45-50 od 2 eur <br /><br /> <a href=""><button class="button">NARUCI</button></a> </p>
    <img src="img/mc.jpg">

  </div>
	
  </div>
  
  
 
 <div class="left">
 
  <!-- CS 1.6 -->
  <div class="gamebg">
  
    <p>Premium lokacija Srbija,<br />ping 5-20 od 8.4 eur<br />Lite lokacija Nemacka,<br />ping 45-50 od 4.2 eur <br /><br /> <a href=""><button class="button">NARUCI</button></a> </p>
    <img src="http://www.kgb-hosting.com/pictures/cs.jpg">

  </div>
  
  <br /><div class="space"></div>
  
  <!-- Samp -->
  <div class="gamebg">
  
    <p>Premium lokacija Srbija,<br />ping 5-20 od 4 eur<br />Lite lokacija Nemacka,<br />ping 45-50 od 2 eur <br /><br /> <a href=""><button class="button">NARUCI</button></a> </p>
    <img src="http://www.kgb-hosting.com/pictures/samp.jpg">

  </div>
  
  <br /><div class="space"></div>
  
  <!-- TS3 -->
  <div class="gamebg">
  
    <p>Premium lokacija Srbija,<br />ping 5-20 od 4 eur<br />Lite lokacija Nemacka,<br />ping 45-50 od 2 eur <br /><br /> <a href=""><button class="button">NARUCI</button></a> </p>
    <img src="img/ts3.png">

  </div>
  
  </div> 
 
 
 
 <br />
 </div>
 
 <div class="footer">&copy; Copyright Frozen Hosting 2014.</div>

