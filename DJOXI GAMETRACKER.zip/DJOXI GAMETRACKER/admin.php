<?php 
defined("access") or die("Nedozvoljen pristup");	
	if(logged_in () == true) {

		$user = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE user_id='$_SESSION[user_id]'"));

		if($user['type'] == "1") {

?>

<div id="admin">

	<h3> Admin panel </h3>
	<p> Dobrodosli u <strong>Djoxi Game Tracker</strong> admin panel!</p>
<div id="ban">
	<h3>Banujte server</h3> 
	<?php 
	if(isset($_POST['banuj_server'])) {

		$ip = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['ip'])));

		$obrisi_servere = mysql_query("UPDATE servers SET ban='1' WHERE ip='$ip'");
		$banuj = mysql_query("INSERT into banovi(ip) VALUES('$ip')");
		if(!$banuj) {

			$_SESSION['error'] = "Doslo je do greske!";
			header("Location:/admin");
		}else {

			$_SESSION['ok'] = "Uspesno ste banovali masinu sa ip: <strong>$ip</strong>";
			header("Location:/admin");

		}
	}

	?>

	<form action="" method="post">

		<input type="text"name="ip" required="required"  placeholder="Upisite IP..."/>  
		<input type="submit" name="banuj_server" value="Banuj server!" class="login_btn" /><br /> 

	</form>

	<h3>UnBan server</h3> 
	<?php 
	if(isset($_POST['unbanuj_server'])) {

		$ip = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['ip'])));

		$obrisi_servere = mysql_query("UPDATE servers SET ban='0' WHERE ip='$ip'");
		$unbanuj = mysql_query("DELETE from banovi WHERE ip='$ip'");
		if(!$unbanuj) {

			$_SESSION['error'] = "Doslo je do greske!";
			header("Location:/admin");
		}else {

			$_SESSION['ok'] = "Uspesno ste unbanovali masinu sa ip: <strong>$ip</strong>";
			header("Location:/admin");

		}
	}

	?>

	<form action="" method="post">

		<input type="text"name="ip" required="required"  placeholder="Upisite IP servera..."/>  
		<input type="submit" name="unbanuj_server" value="UnBan server!" class="login_btn" /><br /> 

	</form>

	<div class="napomena_ban">

		<h3>Napomena!</h3>
		U polja upisite samo IP servera koji zelite da banujete, bez PORTA! 

	</div>

</div>

<div id="resetrank">
	<h3>Restartujte rank serveru:</h3> 


	<?php 

	if(isset($_POST['rrank'])) {

		$ip = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['ip'])));
		$port = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['port'])));

		$server_id = mysql_result(mysql_query("SELECT id FROM servers WHERE ip='$ip' AND port='$port'"),0);


		$reset = mysql_query("UPDATE servers SET glasovi='0' WHERE ip='$ip' AND port='$port'");
		if(!$reset) {

			$_SESSION['error'] = "Greska!";
			header("Location:/admin");

		} else {

			$_SESSION['ok'] = "Uspesno!";
			mysql_query("DELETE FROM glasovi WHERE server='$server_id'");
			header("Location:/admin");
		}
 
	}

	?>

	<form action="" method="post">
		<input type="text" name="ip" placeholder="Ip..." required="required" /> : <input type="text" name="port" placeholder="Port..." required="required" />
		<input type="submit" name="rrank" value="Resetuj rank" class="login_btn">
	</form>

<br />

	<h3>Restartujte rank svim serverima</h3> 


	<?php 

	if(isset($_POST['rrankall'])) {


		$reset = mysql_query("UPDATE servers SET glasovi='0'");
		if(!$reset) {

			$_SESSION['error'] = "Greska!";
			header("Location:/admin");

		} else {

			$_SESSION['ok'] = "Uspesno!";
			mysql_query("DELETE FROM glasovi");
			header("Location:/admin");
		}
 
	}

	?>

	<form action="" method="post">
		<input type="submit" name="rrankall" value="Resetuj rank" class="login_btn">
	</form>



</div>
<br /><br />

<div id="dserver">

	<?php 
	if(isset($_POST['dserver'])) {
		$ip = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['ip'])));
		$port = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['port'])));
		$server_id = mysql_result(mysql_query("SELECT id FROM servers WHERE ip='$ip' AND port='$port'"),0);
		$obrisi_server = mysql_query("DELETE FROM servers WHERE ip='$ip' AND port='$port'");
		if(!$obrisi_server) {

			$_SESSION['error'] = "Greska!";
			header("Location:/admin");

		}else {

			$_SESSION['ok'] = "Uspesno!";
			mysql_query("DELETE FROM shoutbox WHERE server='$server_id'");
			header("Location:/admin");

		}
	}

	?>

	Obrisi server: 	
	<form action="" method="post">	
	<input type="text" name="ip" placeholder="Ip..." required="required" /> : <input type="text" name="port" placeholder="Port..." style="width:50px;" required="required" />
	<input type="submit" name="dserver" value="Obrisi" class="login_btn">
	</form>

</div>


</div>

<br /> 
<br />
<?php 
	
	} // TYPE PROVERA
} // LOGED PROVERA
else {

	$_SESSION['error'] = "Nemate pristup!";
	header("Location:/index.php");

}
?>