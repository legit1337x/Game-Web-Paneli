<?php
defined("access") or die("Nedozvoljen pristup");
if(logged_in () == true) {
?>

<br />
	<div id="pretraga">
		<h4>Lista svih vasih servera:</h4>
		<table class="pretraga_tabble" cellspacing="0">
			<th>Rank</th>
			<th>Igra</th>
			<th>Naziv</th>
			<th>Igraca</th>
			<th>IP:PORT</th>	
			<th>Mod</th>	
			<th>Drzava</th>	
			<th>Mapa</th>				
			<?php

			$query = mysql_query("SELECT * FROM servers WHERE user_id='$_SESSION[user_id]' ORDER by rank asc");
			while($data=mysql_fetch_object($query)){

			$hostname = $data->hostname;
  			if(strlen($hostname) > 30){ 
			$hostname = substr($hostname,0,30); 
			$hostname .= "..."; 
			} 

			?>
			
			<tr>
			<td><?php echo $data->rank; ?></td>
			<td><img src="/img/igre/<?php echo $data->game; ?>.gif" style="width:10px; height:10px;"></td>	
			<td style="text-align:left;"><a class="link" href="/server_info/<?php echo "$data->ip:$data->port"; ?>"><?php echo $hostname; ?></a></td>
			<td><?php echo "$data->broj_igraca/$data->max_igraca"; ?></td>	
			<td><?php echo "$data->ip:$data->port"; ?></td>											
			<td><?php echo $data->mod; ?></td>		
			<td><img src="/img/lokacije/<?php echo $data->drzava; ?>.png" style="height:10px;"></td>				
			<td><?php echo $data->mapa; ?></td>				
			</tr>

			<?php }} else { ?>

			<?php 

			$_SESSION['error'] = "Morate se ulogovati!";
			header("Location:/index.php");

		};?>

		</table>



	</div> <!-- PRETRAGA DIV / -->

<br /> 
