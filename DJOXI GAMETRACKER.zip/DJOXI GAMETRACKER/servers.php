<?php
defined("access") or die("Nedozvoljen pristup");
?>

<br />
	<div id="pretraga">
		<div class="pretraga_box">
		<form action="" method="post">

				<input type="text" name="hostname_search" placeholder="Naziv servera..." /> 
				<input type="text" name="ip_search" placeholder="IP adresa..." /> 				
				<input type="text" name="port_search" placeholder="Port..." /> 
				<input type="text" name="mapa_search" placeholder="Mapa..." /> 
				<select type="text" name="igra_search">
					<option value="cstrike"> Counter Strike 1.6 </option>
				</select>		
				<select type="text" name="drzava_search">				
					<option value="rs"> Srbija </option>
					<option value="ba"> Bosna i Hercegovina </option>	
					<option value="me"> Crna Gora </option>	
					<option value="mk"> Makedonija </option>													
				</select>					
				<input type="submit" name="trazi" value="Pretraga" />

		</form>
		</div> <br />
		<table class="pretraga_tabble" cellspacing="0">

			<th>Rank</th>
			<th>Igra</th>
			<th>Naziv</th>
			<th>Igraca</th>
			<th>IP:PORT</th>	
			<th>Mod</th>	
			<th>Drzava</th>	
			<th>Mapa</th>								

			<?php 
			if(isset($_POST['trazi'])) {

			$shostname=$_POST['hostname_search'];
			$sip=$_POST['ip_search'];
			$sport=$_POST['port_search'];
			$smapa=$_POST['mapa_search'];
			$sigra=$_POST['igra_search'];
			$sdrzava=$_POST['drzava_search'];

			$query = mysql_query("SELECT * FROM servers 
				WHERE ban='0'
				AND
				hostname LIKE '%$shostname%'  
				AND
				ip LIKE '%$sip%'  
				AND
				port LIKE '%$sport%' 
				AND 
				mapa LIKE '%$smapa%'
				AND
				drzava = '$sdrzava'


				ORDER by rank asc");
			while($data=mysql_fetch_object($query)){

			$hostname = $data->hostname;
  			if(strlen($hostname) > 30){ 
			$hostname = substr($hostname,0,30); 
			$hostname .= "..."; 
			} 

			?>
			<tr>
			<td><?php echo $data->rank; ?></td>
			<td><img src="/img/igre/<?php echo $data->game; ?>.gif" style="width:10px; height:10px;"></td>	
			<td style="text-align:left;"><a class="link" href="/server_info/<?php echo "$data->ip:$data->port"; ?>"><?php echo $hostname; ?></a></td>
			<td><?php echo "$data->broj_igraca/$data->max_igraca"; ?></td>	
			<td><?php echo "$data->ip:$data->port"; ?></td>											
			<td><?php echo $data->mod; ?></td>		
			<td><img src="/img/lokacije/<?php echo $data->drzava; ?>.png" style="height:10px;"></td>				
			<td><?php echo $data->mapa; ?></td>				
			</tr>

			<?php }} else { ?>

			<?php

			$query = mysql_query("SELECT * FROM servers WHERE ban='0' ORDER by rank asc");
			while($data=mysql_fetch_object($query)){

			$hostname = $data->hostname;
  			if(strlen($hostname) > 30){ 
			$hostname = substr($hostname,0,30); 
			$hostname .= "..."; 
			} 

			?>
			
			<tr>
			<td><?php echo $data->rank; ?></td>
			<td><img src="/img/igre/<?php echo $data->game; ?>.gif" style="width:10px; height:10px;"></td>	
			<td style="text-align:left;"><a class="link" href="/server_info/<?php echo "$data->ip:$data->port"; ?>"><?php echo $hostname; ?></a></td>
			<td><?php echo "$data->broj_igraca/$data->max_igraca"; ?></td>	
			<td><?php echo "$data->ip:$data->port"; ?></td>											
			<td><?php echo $data->mod; ?></td>		
			<td><img src="/img/lokacije/<?php echo $data->drzava; ?>.png" style="height:10px;"></td>				
			<td><?php echo $data->mapa; ?></td>				
			</tr>

			<?php }}; ?>

		</table>



	</div> <!-- PRETRAGA DIV / -->

<br /> 
