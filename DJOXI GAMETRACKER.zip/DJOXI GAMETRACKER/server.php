<?php 
defined("access") or die("Nedozvoljen pristup");





$ip_port	= explode(":", $_GET['ip'],$_GET['port']);
$ip			= $ip_port[0];
$port		= $ip_port[1];


$result  = mysql_query("SELECT * FROM `servers` WHERE `ip` = '$ip' AND `port` = '$port' ORDER by glasovi DESC");
$server_data = mysql_fetch_array($result, MYSQL_ASSOC);




	

	if($ip_port == "") {
		
		$_SESSION['error'] = "Server ne postoji!";
		header('Location:/index.php');
		
	}
	
	if(!$server_data) {
		
		$_SESSION['error'] = "Server ne postoji!";
		header('Location:/index.php');		
		
	}

	if($server_data['ban'] == "1") {

		$_SESSION['error'] = "Server je banovan!";
		header("Location:/serveri");

	} 

	$server_id  = $server_data['id'];
	$vlasnikid = $server_data['vlasnik'];
	$last_update = time() - $server_data['cache_time'];
	$last_updateM = intval($last_update/60);


	
	try {
		$Query = new LiveStats($server_data['ip'], $server_data['port']);
		$info = $Query->GetServer();
	}
	catch (LSError $e) {}
	
	//Check status of the server
	if(empty($e)){ $status = 1; } else { $status = 0; }
			
	$cache = trim($cache);
	$datum = date('d');

	// Info servera
	$hostname = $info->Hostname;	
	$mapa = $info->Map;		
	$mod = $server_data['mod'];
	$broj_igraca = $info->PlayerCount;
	$max_igraca = $info->MaxPlayers;
	$igra = $server_data['game'];
	if($igra == "cstrike") {

		$igra = "Counter Strike 1.6";

	};
	$online = $server_data['status'];
	if($online == "0") {

		$online = "Ne";
	} else {

		$online = "Da";
	}
	$dodao = mysql_result(mysql_query("SELECT username FROM users WHERE user_id = '$server_data[user_id]'"),0);

	$vlasnik = $server_data['vlasnik'];
	if($vlasnik == "" OR $vlasnik == "0") {

		$vlasnik = "Nema vlasnika";

	} else {

		$vlasnikusername = mysql_result(mysql_query("SELECT username FROM users WHERE user_id = '$server_data[vlasnik]'"),0);
		$vlasnik = "<a href='/korisnik/$vlasnikid'>$vlasnikusername</a>";

	};

	$sajt = $server_data['forum'];
	if($sajt == "") {

		$sajt = "Nema";
	} else {

		$sajt = "<a href='http://$sajt'>$sajt</a>";
	}

	$igraci = "$server_data[broj_igraca]/$server_data[max_igraca]";

	// Prosecan broj igraca
	$players = $server_data['broj_igraca'];
	  
	$niz24 = explode(',' , $players);

	$niz1 = substr($players , 12);
	$niz12 = explode(',' , $niz1);

	$suma = array_sum( $niz24 );
	$suma1 = array_sum( $niz12 );

	$prosek = round($suma / count( $niz24 ), 2);
	$prosek12 = round($suma1 / count( $niz12 ), 2);

	// Mapa
	$mapurl = "/img/mape/$server_data[game]/$server_data[mapa].jpg";

	if (getimagesize($mapurl) !== false) {
	    $mapurl = "/img/mape/$server_data[game]/$server_data[mapa].jpg";
	} else {
	    $mapurl = "/img/mape/$server_data[game]/$server_data[mapa].jpg";
	}
	$glasovi = $server_data['glasovi'];
	$rank = $server_data['rank'];
	if($rank == "0") {

		$rank = "999999";
	}
	
	//update cache
	mysql_query("UPDATE `servers` SET `cache` = '$cache' WHERE `ip` = '$ip' AND `port` = '$port'");
	//Update cache time
	mysql_query("UPDATE `servers` SET `cache_time` = unix_timestamp() WHERE `ip` = '$ip' AND `port` = '$port'");
	//Update cache status of the server
	mysql_query("UPDATE `servers` SET `status` = '$status' WHERE `ip` = '$ip' AND `port` = '$port'");
	
	if($status == "1") { 
	mysql_query("UPDATE `servers` SET `hostname` = '$hostname' WHERE `ip` = '$ip' AND `port` = '$port'");
	mysql_query("UPDATE `servers` SET `mapa` = '$mapa' WHERE `ip` = '$ip' AND `port` = '$port'");
	mysql_query("UPDATE `servers` SET `max_igraca` = '$max_igraca' WHERE `ip` = '$ip' AND `port` = '$port'");
	mysql_query("UPDATE `servers` SET `broj_igraca` = '$broj_igraca' WHERE `ip` = '$ip' AND `port` = '$port'");		
	}


	// INFORMACIJE SERVERA

	if($status == "1") {

		$naziv_servera = $info->Hostname;
		$mapa_ = $info->Map;

	} else {

		$naziv_servera = $server_data['hostname'];
		$mapa_ = $server_data['mapa'];
	}




?>

<div id="serverinfo">

	<div class="title" style="width:610px;"><img src="/img/igre/<?php echo $server_data['game']; ?>.gif" style="width:10px; height:10px;"> <img src="/img/lokacije/<?php echo $server_data['drzava']; ?>.png" style="height:10px;">
		<span style="float:right;">Poslednji update: <?php echo time_ago($server_data['cache_time']); ?></span>
	</div>
	<div class="sibox">
		» Osnovne informacije <br /> <br />

		<p>Naziv: <span class="boja_zelena"><?php echo $naziv_servera; ?></span> </p>
		<p>Mod: <span class="boja_zelena"><?php echo $mod; ?></span> </p>	
		<p>Igra: <span class="boja_zelena"><img src="/img/igre/<?php echo $server_data['game']; ?>.gif" style="width:10px; height:10px;"> <?php echo $igra; ?></span> </p>			
		<p>Online: <span class="boja_zelena"><?php echo $online; ?></span> </p>
		<p>IP Adresa: <span class="boja_zelena"><?php echo "$ip:$port"; ?></span> </p>
		<p>Dodao: <span class="boja_zelena"><a href="/korisnik/<?php echo $server_data['user_id']; ?>"><?php echo $dodao; ?></a></span> </p>
		<p>Vlasnik: <span class="boja_zelena"><?php echo $vlasnik; ?><a href="/process/vlasnistvo/<?php echo "$ip:$port"; ?>"> [ Potvrdi vlasnistvo ] </a> </span> </p>
		<br />
		» Dodatne informacije <br /> <br />
		<p>Sajt/forum: <span class="boja_zelena"><?php echo $sajt; ?></span> <?php if($vlasnikid == $_SESSION['user_id']) { ?> <span class="izmeni"><a data-popup-open="izmeni" href="#"> IZMENI </a></span> <?php };?></p>
		<br />
		» Informacije o igracima <br /> <br />
		<p>Igraca: <span class="boja_zelena"><?php echo $igraci; ?></span> </p>
		<p>Prosecan broj igraca (poslednjih 12h): <span class="boja_zelena"><?php echo $prosek12; ?></span> </p>	
		<p>Prosecan broj igraca (poslednjih 24h): <span class="boja_zelena"><?php echo $prosek; ?></span> </p>			
		<br />	
		» Rank & Glasovi <br /> <br />
		<p>Broj glasova: <span class="boja_zelena"><?php echo $glasovi; ?></span> </p>
		<p>Rank: <span class="boja_zelena"><?php echo $rank; ?></span> </p>
				
		<br />	
		<div class="mapaservera">			
			<img src="<?php echo $mapurl; ?>" style="width:150px; height:110px;"> <br />
			Trenutna mapa: <?php echo $mapa_; ?>
		</div>
		<div id="baneri">
  		<h3>Banneri</h3>

		<img src="/banner/<?php echo "$ip:$port"; ?>"> <br /><br />
		HTML Kodovi <br />
		<textarea cols="60" rows="1" title="HTML code" onclick="this.select()" readonly="readonly"><a href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/server_info/<?php echo "$ip:$port"; ?>" target="_blank"><img src="/banner/<?php echo "$ip:$port"; ?>" border="0"></a></textarea> <br />
		Forum Kodovi: <br />
		<textarea cols="60" rows="1" title="Forum code" onclick="this.select()" readonly="readonly">[url=http://<?php echo $_SERVER['SERVER_NAME']; ?>/server_info/<?php echo "$ip:$port"; ?>][img]http://<?php echo $_SERVER['SERVER_NAME']; ?>/banner/<?php echo "$ip:$port"; ?>[/img][/url]</textarea><br /><br /><br />
		</div>

		<div id="oceni">
			<div class="title">Glasajte za server</div>
		<div class="glas">
			<div class="glasaj_btn"><span style="font-size:16px;"><?php echo $server_data['glasovi']; ?> glasova</span> <span><a href="/glasaj/<?php echo "$server_id"; ?>">GLASAJ</a></span></div>
		</div>
		</div> <br />
		<div id="shoutbox">

			<div class="title">ShoutBox</div>
			
			<?php 

				$sbp 	= mysql_num_rows(mysql_query("SELECT id FROM shoutbox WHERE server='$server_id'"));
				if($sbp <1) {

					echo "<div class='shoutbox_komentar'>Nema komentara!</div>";
				} else {

				$kveri = mysql_query("SELECT * FROM shoutbox WHERE server='$server_id' ORDER by id DESC LIMIT 5");
				while($sb = mysql_fetch_array($kveri)) {
				$komentar = $sb['komentar'];
								  if(strlen($komentar) > 120){ 
							          $komentar = substr($komentar,0,120); 
							          $komentar .= "..."; 
							     }
			?>			
			<div class="shoutbox_komentar">
				<div class="komentar">
					<?php echo $komentar; ?> <hr />
					Comment by: <strong><a href="/korisnik/<?php echo $sb['user_id']; ?>"><?php echo $sb['username']; ?></a></strong>
				</div>
			</div>	

			<?php }}; ?>
			<div class="sbl"> 
			<?php if(logged_in () == false) { ?>
			<img src="/img/info.png"> <span style="margin-left:20px;">Ulogujte se i ostavite komentar!</span> 
			<?php } else { ?>

			<?php 

				if(isset($_POST['submit'])) {

					$user_id 	= $_SESSION['user_id'];
					$username 	= mysql_result(mysql_query("SELECT username FROM users WHERE user_id='$user_id'"),0);					
					$komentar 	= htmlspecialchars(mysql_real_escape_string(addslashes($_POST['sbk'])));

					$ubaci = "INSERT into shoutbox(user_id,username,komentar,server) VALUES('$user_id','$username','$komentar','$server_id')";
					$kveri = mysql_query($ubaci);

					if(!$ubaci) {

						die("<script> alert('Doslo je do greske!'); document.location.href='/server_info/$ip:$port'; </script>");

					} else {

						die("<script> alert('Uspesno ste ostavili komentar!'); document.location.href='/server_info/$ip:$port'; </script>");
					}

				} // submit

			?>

			<form action="" method="post">
				<textarea type="text" name="sbk" required="required" placeholder="Upisite vas komentar..."></textarea> <br />
				<input type="submit" name="submit"  class="sbs" value="Komentarisi"></input>
			</form>

			<?php }; ?>
			</div>
		</div>	



		<br /><br />
		<div class="title"> Online igraci na serveru </div> 

		<table class="online_igraci" cellspacing='0'>
			<thead>
				<th>Nick</th>
				<th>Skor</th>
				<th>vreme</th>
			</thead>
			<tbody>
				<?php

					foreach($info->Players as $online_igraci){
						
						echo "
							<tr>
								<td>{$online_igraci->Name}</td>
								<td>{$online_igraci->Score}</td>
								<td>{$online_igraci->TimePlayed}</td>
							</tr>";
					}
				?>
			</tbody>
		</table>		

	</div>	



</div>

<!-- POPUP PROZORI :D -->

				<div class="popup" data-popup="izmeni">
				<div class="popup-inner">
					<div class="popup-title"><center> Izmenite sajt za <?php echo $server_data['hostname']; ?> </center></div>				
					<center>
						<?php 

						

							if(isset($_POST['izmeni'])) {

								$sajt = $_POST['sajt'];
								$kveri = mysql_query("UPDATE servers SET forum='$sajt' WHERE ip='$ip' AND port='$port'");
								if(!$kveri) {

									$_SESSION['error'] = "Greska!";
									header("Location:/server_info/$ip:$port");
								} else {

									$_SESSION['ok'] = "Uspesno!";
									header("Location:/server_info/$ip:$port");

								}
							}

						?>

						<h3> Uputstvo: </h3>
						» U polje ispod upisite link sajta bez <span style="color:#07939F;">http://</span>! (Primer: <span style="color:#07939F;">www.djoxi.com</span>) <br />
						» Ukoliko ne zelite da server ima sajt ostavite polje prazno!
						<br /><br />
						<form action="" method="POST">
						<input type="text" name="sajt" class="djoxi" placeholder="Link sajta..."></input><br /> <br />
						<input type="submit" name="izmeni" class="login_btn" value="IZMENI"></input>
						
						</form>
					</center>
					<a class="popup-close" data-popup-close="izmeni" href="#">x</a>
					</div>
				</div>	



<br /> <br />

