<?php 
if(logged_in () == false) {

	$_SESSION['error'] = "Morate se ulogovati!";
	header("Location:/index.php");
}
else {
if(isset($_POST['provera_servera'])) {
$_POST['ip_address'] = htmlspecialchars($_POST['ip_address'], ENT_QUOTES);

	//Server checks
	try {
		$Query = new LiveStats($_POST['ip_address'], $_POST['connection_port']);
		$info = $Query->GetServer();
	}
	catch (LSError $e) {}
				
	//Check status of the server
	if(empty($e)){ $status = 1; } else { $status = 0; }
	
}
if(isset($_POST['add_server'])) {
	$ip   	  = htmlspecialchars($_POST['ip'], ENT_QUOTES);
	$port 	  = htmlspecialchars($_POST['port'], ENT_QUOTES);
	$mod  = htmlspecialchars($_POST['mod']);
	$game 	  = htmlspecialchars($_POST['igra'], ENT_QUOTES);
	$naziv_srv 	  = htmlspecialchars($_POST['hostname']);
	$drzava  = htmlspecialchars($_POST['drzava']);

	$ban = mysql_num_rows(mysql_query("SELECT ip FROM banovi WHERE ip='$ip'"));
	if($ban > 0) {

		$_SESSION['error'] = "IP Je banovan!";
		header("Location:/dodaj_server");
		exit();
	} 


	$ubaci = mysql_query("INSERT INTO `servers` (`hostname`,`user_id`, `ip`, `port`, `game`,`drzava`,`mod`) VALUES ('$naziv_srv','$_SESSION[user_id]', '$ip', '$port', '$game','$drzava','$mod')");
	if(!$ubaci) {

		$_SESSION['error'] = "Doslo je do greske!";
		header('Location:/dodaj_server');

	} else {

		$_SESSION['ok'] = "Uspesno ste dodali server!";
		header("Location:/server_info/$ip:$port");

	}

	
}
?>
<div id="welcome">
<h3>Dodaj novi server:</h3>
<p>Popunite formular i dodajte server!</p><hr />
<?php
if(isset($_POST['provera_servera'])) {

	$game	  = $_POST['game'];

	if(server_exists2($_POST['ip_address'], $_POST['connection_port'])) {
		$_SESSION['error'] = "Server vec postoji u bazi!";
		header("Location:/server_info/$_POST[ip_address]:$_POST[connection_port]");
	}

	if($status == 0) {
		$_SESSION['error'] = "Server je offline!";
		header("Location:/dodaj_server");
	}

	if(!$info->Directory == "cstrike") {
		$_SESSION['error'] = "Server nije Counter Strike!";
		header("Location:/dodaj_server");
	}

}
if(isset($_GET['success']) && empty($_GET['success'])) {
	echo '<div class="alert alert-success">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
			<strong>Congratulations!</strong> Your server has been added!';
	if($settings['server_confirmation'] == '1') echo "&nbsp;&nbsp; Please wait for admin approval!";
	echo '</div>';
}

if(empty($errors) == false) {
	echo output_errors($errors);
}

?>

<form method="post" action="">
	<label>Igra</label> <br />
	<select type="text" name="igra">
		<option value="cstrike"> Counter Strike 1.6 </option>
	</select> <br /> <br />
	
	<label>IP Addresa</label><br />
	<input type="text" name="ip_address"  />
	<br /><br />

	<label>Port</label><br />
	<input type="text" name="connection_port" value="27015" maxlength="5"/><br />
	<br /> <br />

	<label>Drzava</label> <br />
	<select type="text" name="drzava">
		<option value="RS"> Srbija </option>
		<option value="BA"> Bosna i Hercegovina </option>
		<option value="ME"> Crna Gora </option>		
		<option value="MK"> Makedonija </option>					
	</select> <br /> <br />

	<label>Mod</label> <br />
	<select type="text" name="mod">
		<option value="Public"> Public </option>		
		<option value="ClanWar"> ClanWar </option>	
		<option value="DeathMatch"> DeathMatch </option>	
		<option value="DeathRun"> DeathRun </option>
		<option value="Zombie"> Zombie </option>
		<option value="GunGame"> GunGame </option>
		<option value="PaintBall"> PaintBall </option>																			
	</select> <br /> <br />

	<input class="add_server_btn" type="submit" name="provera_servera" value="Dalje" /><br /><br />
	
	<?php if(isset($_POST['provera_servera']) && $status == 1 && empty($errors) ){ ?>
		<br />

		Hostname: <br /><input type="text" name="hostname_provera" disabled value="<?php echo $info->Hostname; ?>" />

		<br /><br />

		<input type="text" name="hostname" hidden value="<?php echo $info->Hostname; ?>" />
		<input type="text" name="ip" hidden value="<?php echo $_POST['ip_address']; ?>" />
		<input type="text" name="port" hidden value="<?php echo $_POST['connection_port']; ?>" />
		<input type="text" name="drzava" hidden value="<?php echo $_POST['drzava']; ?>" />
		<input type="text" name="mod" hidden value="<?php echo $_POST['mod']; ?>" />

		<input class="add_server_btn" type="submit" name="add_server" value="Dodaj server" />


		
<?php } 
?>

<?php };?>
</form>
</div>
<div id="uputstva">

	<h3> Upozorenje! </h3> <hr />

	» Pravi serveri sa vise od dva bota dobice restart ranka ! <hr />
	» Fake serveri bice obrisani i IP banovan ! <hr />
	» GameMenu koji menja default opcije je ZABRANJEN ! <hr />
	» Serveri koji imaju auto connect ce biti obrisani i BANOVANI ! <hr />
	» Serveri koji menjaju bitne game fajlove ce biti obrisani i IP banovan ! <hr />

</div>
<br /> <br />


