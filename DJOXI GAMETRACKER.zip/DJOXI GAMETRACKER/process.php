<?php
ob_start(); 
session_start();
//error_reporting(0);
require 'connect.php';

date_default_timezone_set('Europe/Belgrade');




if(logged_in() == true){
	$session_user_id = $_SESSION['user_id'];
	$user_data = user_data($session_user_id, 'user_id', 'ime','prezime','username', 'password', 'email', 'type', 'avatar');
	if(user_active($user_data['username']) == false){
		session_destroy();
		header('Location: index.php');
		exit();
	}
	
	mysql_query("UPDATE `users` SET `last_activity` = unix_timestamp() WHERE `user_id` = '$session_user_id'");
}
if(logged_in() == false){
	$guest_ip = $_SERVER['REMOTE_ADDR'];
	$query = mysql_query("SELECT COUNT(`ip`) FROM `guests` WHERE `ip` = '$guest_ip'");
	if(mysql_result($query, 0) == 1){
		mysql_query("UPDATE `guests` SET `last_activity` = unix_timestamp() WHERE `ip` = '$guest_ip'");
	} else {
		mysql_query("INSERT INTO `guests` (`ip`, `last_activity`) VALUES ('$guest_ip', unix_timestamp())");
	}
		mysql_query("DELETE FROM `guests` WHERE `last_activity` < unix_timestamp() - 30");
}

$settings = settings_data(1, 'title', 'facebook', 'twitter', 'contact_email', 'pagination', 'register', 'show_offline_servers', 'server_cache', 'email_confirmation', 'server_confirmation', 'advertise_top', 'advertise_bottom');
require 'titles.php';

$errors = array();

// FUNKCIJE 

function send_avatar($file_temp, $file_extension) {
	global $file_path;
	$file_path = 'avatars/' . substr(md5(time()), 0, 10) . '.' . $file_extension;
	move_uploaded_file($file_temp, $file_path);
}
function online_users() {
	$online_users = mysql_num_rows(mysql_query("SELECT `user_id` FROM `users` WHERE `last_activity` > unix_timestamp() - 30"));//in seconds
	echo $online_users;
}
function online_guests() {
	$online_users = mysql_num_rows(mysql_query("SELECT `ip` FROM `guests` WHERE `last_activity` > unix_timestamp() - 30"));//in seconds
	echo $online_users;
}
function update_user($user_id, $update_data) {
	$update = array();
	array_walk($update_data, 'array_sanitize');
	
	foreach($update_data as $field=>$data) {
		$update[] = '`' . $field . '` = \'' . $data .'\'';
	}
		
	mysql_query("UPDATE `users` SET " . implode(', ', $update) . " WHERE `user_id` = $user_id ");
}

function is_admin($user_id) {
	$user_id = (INT)$user_id;
	return (mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `user_id` = $user_id AND `type` = 1"), 0) == 1) ? true : false;
	return ($user_data['type'] == 1) ? true : false;
}

function activate($email, $email_code) {
	$email		= mysql_real_escape_string($email);
	$email_code = mysql_real_escape_string($email_code);
	
	if(mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `email` = '$email' AND `email_code` = '$email_code' AND `active` = 0"), 0) == 1) {
		mysql_query("UPDATE `users` SET `active` = 1 WHERE `email` = '$email'");
		return true;
	} else {
		return false;
	}
}

function change_password($user_id, $password) {
	$user_id = (int)$user_id;
	$password = md5($password);
	
	mysql_query("UPDATE `users` SET `password` = '$password' WHERE `user_id` = $user_id");
}

function register_user($register_data) {
	array_walk($register_data, 'array_sanitize');
	$register_data['password'] = md5($register_data['password']);
	$active = $register_data['active'];
	$fields = '`' . implode('`, `', array_keys($register_data)) . '`';
	$data = '\'' . implode('\', \'', $register_data) . '\'';
	
	mysql_query("INSERT INTO `users` ($fields) VALUES ($data)");
	if($active == '0'){
		sendmail($register_data['email'], 'Activate your account', "
			Hello " . $register_data['name'] . ",\n\n
			To activate your account, access the link below:\n\n
			http://changeme.com/activate.php?email=" . $register_data['email'] . "&email_code=" . $register_data['email_code'] . " \n\n
		");
	}
}
function user_count() {
	return mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `active` = 1"), 0);
}
function disabled_users_count() {
	return mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `active` = 0"), 0);
}

function user_data($user_id) {
	$data = array();
	$user_id = (int)$user_id;
	
	$func_num_args = func_num_args();
	$func_get_args = func_get_args();
	
	if($func_num_args > 0) {
		unset($func_get_args[0]);
		$fields = '`' . implode('`, `', $func_get_args) . '`';
		$data = mysql_fetch_assoc(mysql_query("SELECT $fields FROM `users` WHERE `user_id` = '$user_id'"));
		
		return $data;
	}
}

function logged_in() {
	return (isset($_SESSION['user_id'])) ? true : false;
}

function email_exists($email) {
	$email = sanitize($email);
	$query = mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `email` = '$email'");
	return (mysql_result($query, 0) == 1) ? true : false;
}

function user_exists($username) {
	$username = sanitize($username);
	$query = mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `username` = '$username'");
	return (mysql_result($query, 0) == 1) ? true : false;
}

function user_active($username) {
	$username = sanitize($username);
	$query = mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `username` = '$username' AND `active` ='1'");
	return (mysql_result($query, 0) == 1) ? true : false;
}

function user_id_from_username($username) {
	$username = sanitize($username);
	$query = mysql_query("SELECT `user_id` FROM `users` WHERE `username` = '$username'");
	return mysql_result($query, 0, 'user_id');
}
function username_from_user_id($user_id) {
	$username = sanitize($user_id);
	$query = mysql_query("SELECT `username` FROM `users` WHERE `user_id` = '$user_id'");
	return @mysql_result($query, 0, 'username');
}
function login($username, $password) {
	$user_id = user_id_from_username($username);
	$username = sanitize($username);
	$password = md5($password);
	$query = mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `username` = '$username' AND `password` = '$password'");
	return (mysql_result($query, 0) == 1) ? $user_id : false;
}

function string_resize($string, $maxchar) {
	$length = strlen($string);
	if($length > $maxchar) {
		$cutsize = -($length-$maxchar);
		$string  = substr($string, 0, $cutsize);
		$string  = $string . "..";
	}
	return $string;
}

function settings_data($id) {
	$data = array();
	$user_id = (int)$id;
	
	$func_num_args = func_num_args();
	$func_get_args = func_get_args();
	
	if($func_num_args > 0) {
		unset($func_get_args[0]);
		$fields = '`' . implode('`, `', $func_get_args) . '`';
		$data = mysql_fetch_assoc(mysql_query("SELECT $fields FROM `settings` WHERE `id` = '$id'"));
		
		return $data;
	}
}

function current_page_name() {
	return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}

function sendmail($to, $subject, $body) {
	mail($to, $subject, $body, 'From: No-Reply!');
}

function logged_in_redirect() {
	if(logged_in() == true) {
		header('Location: index.php');
	}
}

function protect_page() {
	if(logged_in() == false) {
		header('Location: access.php');
		exit();
	}
}

function admin_page() {
	global $user_data;
	if(is_admin($user_data['user_id']) == false) {
		header('Location: index.php');
		exit();
	}


}

function array_sanitize(&$item) {
	$item = mysql_real_escape_string($item);
}

function sanitize($data) {
	return mysql_real_escape_string($data);
}

function output_errors($errors) {
	return '
	<div class="alert alert-error" style="padding-top:15px;">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<ul><li>' . implode('</li><li>', $errors) . '</li></ul>
	</div>
	'; 
}

?>


<?php

	// SERVERI F-JE


function server_exists2($ip, $port) {
	$ip = sanitize($ip);
	$query = mysql_query("SELECT COUNT(`ip`) FROM `servers` WHERE `ip` = '$ip' AND `port` = '$port'");
	return (mysql_result($query, 0) == 1) ? true : false;
}
function server_exists($ip) {
	$ip = sanitize($ip);
	$query = mysql_query("SELECT COUNT(`ip`) FROM `servers` WHERE `ip` = '$ip'");
	return (mysql_result($query, 0) == 1) ? true : false;
}

function get_country($ip) {
	if(!is_numeric($ip)){
		$ip = gethostbyname($ip);
	}
	$current_dir    = explode("/" ,$_SERVER['REQUEST_URI']);
	$current_dir    = array_slice($current_dir, 0, -1);
	$current_dir    = implode("/", $current_dir);
	$link 			= "http://api.wipmania.com/" . $ip;
	@$country 		= (file_get_contents($link)) ? file_get_contents($link) : "XX";
	//$icon   		= "http://" . $_SERVER['SERVER_NAME'] . $current_dir . "/includes/locations/" . $country . ".png";
	return $country ;
}

/* function country_icon_location($ip) {
	if(!is_numeric($ip)){
		$ip = gethostbyname($ip);
	}
	$ctx=stream_context_create(array('http'=>
		array('timeout' => 2)
	));
	
	$current_dir    = explode("/" ,$_SERVER['REQUEST_URI']);
	$current_dir    = array_slice($current_dir, 0, -1);
	$current_dir    = implode("/", $current_dir);
	$link 			= "http://api.ipinfodb.com/v3/ip-city/?key=abe0dc606dec2fbf07c3a3d08103995a1d01f31afb171118b39b87c10b89cf6f&ip=" . $ip;
	$file	 		= file_get_contents($link,false,$ctx);
	$exploded		= explode(";", $file);
	$country 		= $exploded[3];
	$icon   		= "http://" . $_SERVER['SERVER_NAME'] . $current_dir . "/includes/locations/" . $country . ".png";
	return "<img src=\"" . $icon . "\" />";
	// print_r($current_dir);
} */

function server_vip($server_id) {
	$server_id = (INT)$server_id;
	return (mysql_result(mysql_query("SELECT `vip` FROM `servers` WHERE `id` = $server_id"), 0) == 1) ? 1 : 0;
}
function servers_count() {
	return mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `servers` WHERE `disabled` = 0"), 0);
}
function disabled_servers_count() {
	return mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `servers` WHERE `disabled` = 1"), 0);
}

function HexToRGB($hex) {
		$hex = str_replace("#", "", $hex);
		$color = array();
 
		if(strlen($hex) == 3) {
			$color['r'] = hexdec(substr($hex, 0, 1) . $r);
			$color['g'] = hexdec(substr($hex, 1, 1) . $g);
			$color['b'] = hexdec(substr($hex, 2, 1) . $b);
		}
		else if(strlen($hex) == 6) {
			$color['r'] = hexdec(substr($hex, 0, 2));
			$color['g'] = hexdec(substr($hex, 2, 2));
			$color['b'] = hexdec(substr($hex, 4, 2));
		}
		return $color;
}
	
	
function id_to_user_id($id) {
	$id = sanitize($id);
	$query 	= mysql_query("SELECT `user_id` FROM `servers` WHERE `id` = '$id'");
	$data = mysql_fetch_assoc($query);
	return $data['user_id'];
}


 if (isset($_GET['task']) && $_GET['task'] == "potvrdi_vlasnistvo") {
  $ip_port	= explode(":", $_GET['ip']&$_GET['port']);
  $ip			= $ip_port[0];
  $port		= $ip_port[1];
  $vreme = time();
  
  $info = mysql_fetch_array(mysql_query("SELECT * FROM servers WHERE ip='$ip' AND port='$port'"));
  
  if($_SESSION['user_id'] == ""){
   $_SESSION['error'] = "Morate se ulogovati!";
   header("location:/server_info/$ip:$port");
   die();
  }
  
  if($info['ip'] && $info['port'] == ""){
   $_SESSION['error'] = "Server koji trazite ne postoji";
   header("location:/serveri");
   die();
  }
  
  $server_id = $info['id'];
  $game = $info['game'];
  

  if($info['hostname'] == "Djoxi GameTracker" && $info['status'] == "1"){
    mysql_query("UPDATE servers SET vlasnik='$_SESSION[user_id]' WHERE id='$server_id'");
	$_SESSION['ok'] = "Uspesno ste potvrdili vlasnistvo";
	header("location:/server_info/$ip:$port");
  } else {
    $_SESSION['error'] = "Ime servera mora biti  <strong>Djoxi GameTracker</strong>";
	header("location:/server_info/$ip:$port");
	die();
  } 
  }
else if (isset($_GET['task']) && $_GET['task'] == "upload_avatar") {
    $time = time();
    $userid = $_SESSION['user_id'];
    if(isset($_FILES["file"])){
    $userid = $_SESSION['user_id'];
    $errors = array();
    $allowed_ext = array('phtml','php','php3','php4','php5','php6','phps','cgi','exe','pl','asp','aspx','shtml','shtm','fcgi','fpl','jsp','htm','html','wml');
    $namn = $_FILES["file"]["name"];
	$value = explode(".", $namn);
    $ext = strtolower(array_pop($value));  
    $size = $_FILES["file"]["size"];
    $tmp = $_FILES["file"]["tmp_name"];
    if(in_array($ext, $allowed_ext) === true){
    $_SESSION['error'] = 'Tip fajla nije dozovljen';
	header("location:/index.php");
	die();
    }
    if(empty($errors)){
    $name = time().'.'.$ext;
    if(move_uploaded_file($tmp,"avatari/".$name)){
	mysql_query("UPDATE users SET avatar='$name' WHERE user_id='$_SESSION[user_id]'");
	header("location:/index.php");
    } else {
    $_SESSION['error'] = "Niste izabrali sliku";
	header("location:/index.php");
    die();
    }
    }else {
    foreach ($errors as $error){
    $_SESSION['error'] = "Error";
	header("location:/index.php");
	die();
    }
    }
        
    } else {
    $_SESSION['error'] = "Error";
	header("location:/index.php");
	die();
    }


}
?>