<?php
defined("access") or die("Direktan pristup odbijen!");
logged_in_redirect();

if(empty($_POST) == false) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(empty($username) || empty($password)) {
		$_SESSION['error'] = 'Sva polja moraju biti popunjena!';
		header('Location:index.php');
	} else if(user_exists($username) == false) {
		$_SESSION['error'] = 'Korisnik ne postoji!';
		header('Location:index.php');
	} else if(user_active($username) == false) {
		$_SESSION['error'] = 'Nalog nije aktivan!';
		header('Location:index.php');
	} else {
		$login = login($username, $password);
		if($login == false) {
		$_SESSION['error'] = 'Pogresni podaci!';
		header('Location:index.php');
		} else {
			$_SESSION['user_id'] = $login;
			$_SESSION['ok'] = 'Uspesan login!';
			header('Location:index.php');
			exit();
		}
	}
	if(empty($errors) == false) {
		echo '<h2>Login failed...</h2>';
		echo output_errors($errors);
	}
} else {
?>

<?php };?>
