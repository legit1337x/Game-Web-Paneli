<?php

error_reporting(0);

$database = array();
$database['host']     = 'localhost';
$database['user']     = 'djoxi_gt1';
$database['password'] = 'rpWktLX;$D$$';
$database['table']    = 'djoxi_gt';

$connect_error = 'Sorry, there are some connection problems.';
mysql_connect($database['host'], $database['user'], $database['password']) or die($connect_error);
mysql_select_db($database['table']) or die($connect_error);

date_default_timezone_set('Europe/Belgrade');
$vreme = date("m:i");


// Time ago function
function time_ago($timestamp){
	$difference = time() - $timestamp;
	if($difference < 60){
		return $difference."s";
	} else {
		$difference = round($difference / 60);
		if($difference < 60){
			return $difference."m";
		} else {
			$difference = round($difference / 60);
			if($difference < 24){
				return $difference."h";
			} else {
				$difference = round($difference / 24);
				if($difference < 7){
					return $difference."d";
				} else {
					$difference = round($difference / 7);
					return $difference."w";
				}
			}
		}
	}
}


  $ip_port	= explode(":", $_GET['ip']&$_GET['port']);
  $ip			= $ip_port[0];
  $port		= $ip_port[1];

  $srv = mysql_fetch_array(mysql_query("SELECT * FROM servers WHERE ip='$ip' AND port='$port'"));


// STATISTIKE :D

function registrovanih_korisnika () {

	$reg_kor = mysql_num_rows(mysql_query("SELECT user_id FROM users"));
	echo $reg_kor;

}

function gostiju () {
	$online_users = mysql_num_rows(mysql_query("SELECT `ip` FROM `guests` WHERE `last_activity` > unix_timestamp() - 30"));//in seconds
	echo $online_users;
}

function online_korisnika () {
	$online_users = mysql_num_rows(mysql_query("SELECT `user_id` FROM `users` WHERE `last_activity` > unix_timestamp() - 30"));//in seconds
	echo $online_users;
}


function ukupno_servera () {
	$ukupno_servera = mysql_num_rows(mysql_query("SELECT `id` FROM `servers`"));
	echo $ukupno_servera;
}




?>