<?php 
include 'process.php';
include 'q.php';


$rankquery = mysql_query("SELECT * FROM servers ORDER by glasovi DESC");
while($srank = mysql_fetch_array($rankquery)) {

	$rank++;
	$update = mysql_query("UPDATE servers SET `rank`='$rank' WHERE id='$srank[id]'");

}



?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $pageTitle; ?></title>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/style.css" />
	<link rel="stylesheet" href="../css/djoxi.css" />	
	<link rel="shortcut icon" href="includes/img/favicon.ico" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script type="text/javascript" src="../popup.js"></script>	
	<link href='http://fonts.googleapis.com/css?family=Shadows+Into+Light' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Architects+Daughter' rel='stylesheet' type='text/css'>		
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600" rel="stylesheet" type="text/css" />	
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>	

</head>
<body>


     <?php
     if(isset($_SESSION['ok'])){
	 $ok = $_SESSION['ok'];
	 echo "<div class='succ'><br /><p><center><font color='white'>$ok</font></center></p></div></div>";
	 unset($_SESSION['ok']);
     } else {}
     if(isset($_SESSION['error'])){
  	 $greske = $_SESSION['error'];
	 echo "
          <div class='error'><p><center><br /><font color='white'>$greske</font></center></p></div></div>";
	 unset($_SESSION['error']);
     } else {}
     ?>

<div id="header"></div>
<div id="omot">
<div class="header">Dobrodosli na <strong>Djoxi GameTracker</strong>!</div>
<div class="ucp">
	<?php 
	if(logged_in () == true) {
	$uinfo = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE user_id='$_SESSION[user_id]'"));
	?>
	<a style="color:#fff; text-decoration:none;" href="/korisnik/<?php echo $uinfo['user_id']; ?>"><img src="/img/lokacije/<?php echo $uinfo['drzava']; ?>.png" style="height:10px;"> <?php echo $uinfo['username']; ?></a> <a style="color:#fff; text-decoration:none;" data-popup-open="podesavanje" href="#">Podesavanje</a> <a style="color:#fff; text-decoration:none;" data-popup-open="novi_pw" href="#">Promeni password</a>  <a style="color:#fff; text-decoration:none;" data-popup-open="cavatar" href="#">Promeni avatar</a>  <a style="color:#fff; text-decoration:none;" href="/moji_serveri">Moji serveri</a>
	<?php if($uinfo['type'] == "1") { ?><a style="color:#fff; text-decoration:none;" href="/admin">Admin Panel</a> <?php };?>
	<?php };?>
</div>
<div id="nav">

	<a href="/index.php"> HOME </a>
	<a href="/serveri"> SERVERI </a>
	<a href="#"> FORUM </a>
	<?php if(logged_in () == false) { ?>
	<a data-popup-open="registracija" href="#"> REGISTRACIJA </a>
	<a data-popup-open="login" href="#"> LOGIN </a>
	<?php };?>	
	<?php 
	if(logged_in () == true) {
	?>
	<a href="/logout.php"> ODJAVI SE </a>
	<?php };?>
	

</div>

<div id="bb">

<br /> 


		<?php
		define("access", 1);
		error_reporting(0);
		if($_GET['page'] == "server_info"){
		   include("server.php");
		}else 
		if($_GET['page'] == "glasaj") {
			include("glasaj.php");
		}else
		if($_GET['page'] == "login") {
			include("login.php");
		}
		else
		if($_GET['page'] == "dodaj_server") {
			include("dodaj_server.php");
		}	
		else
		if($_GET['page'] == "serveri") {
			include("servers.php");
		}
		else 
		if($_GET['page'] == "pretraga"){
   		include("pretraga.php");   	
   		}
		else 
		if($_GET['page'] == "moji_serveri"){
   		include("moji_serveri.php");   	
   		}								
		else 
		if($_GET['page'] == "korisnik"){
   		include("korisnik.php");   	
   		}			   
		else 
		if($_GET['page'] == "srv"){
   		include("srv.php");   	
   		} 
		else 
		if($_GET['page'] == "admin"){
   		include("admin.php");   	
   		}    				
   		else {
		?>
		

		<div id="welcome">

			<h2>DJOXI GameTracker v1 beta </h2>
			Dobrodosli na DjoxiTracker v1! <br />
			» Registrujte se! <br />
			» Dodajte vas server! <br /><br />
			<a class="btn" href="/dodaj_server">Dodaj server</a> <br /><br />
			<hr />
			<span style="font-size:11px;">Za vise informacija o GameTracker-u pisite na <span style="color:#0768AD;">djordjeradovanovicvrba@gmail.com</span></span>
		</div>
		<br /> 
		<div id="add_banner"></div>
		<br /> 
		<div id="novi_korisnici">
		<div class="title">
			Novi korisnici
		</div>
		<?php 

			$novi_korisnici = mysql_query("SELECT * FROM users ORDER by user_id DESC LIMIT 5");
			while($nk = mysql_fetch_array($novi_korisnici)) {

		?>
		<div class="novi_korisnici">
		<img src="/img/lokacije/<?php echo $nk['drzava']; ?>.png"> <a class="link" href="/korisnik/<?php echo $nk['user_id']; ?>"><?php echo $nk['username']; ?></a> <br />
		</div>
		<?php }; ?>
		<br />
		<div class="title">
			Statistike GameTrackera
		</div>
		<div class="statistike">
			Registrovanih korisnika: <?php echo registrovanih_korisnika (); ?>
		</div>
		<div class="statistike">
			Gostiju: <?php echo gostiju (); ?>
		</div>	
		<div class="statistike">
			Online korisnika: <?php echo online_korisnika (); ?>
		</div>	
		<div class="statistike">
			Ukupno servera u bazi: <?php echo ukupno_servera (); ?>
		</div>	
		</div>
		<?php };?>


		<div id="top_servers">
			<div class="title_servers">
				Najbolji serveri
			</div>
			<?php 

				$kveri = mysql_query("SELECT * FROM servers ORDER by glasovi DESC LIMIT 10");
				while($server = mysql_fetch_array($kveri)) {
				$serverid = $server['id'];
				$r1++;
				$ip = $server['ip'];
				$port = $server['port'];
				$hostname = $server['hostname'];
				  if(strlen($hostname) > 40){ 
			          $hostname = substr($hostname,0,40); 
			          $hostname .= "..."; 
			     }

			?>
		<div class="boxserver">
			<?php echo $r1;?>. <img src="/img/igre/<?php echo $server['game']; ?>.gif" style="width:10px; height:10px;"> <img src="/img/lokacije/<?php echo $server['drzava']; ?>.png" style="height:10px;"> <a href="/server_info/<?php echo "$ip:$port"; ?>"> <?php echo $hostname; ?></a> <br />
		</div>
			<?php }; ?>
		</div> <!-- TOP SERVERI KRAJ -->


		<div id="random_servers">
			<div class="title_servers">
				Random serveri
			</div>
			<?php 

				$kveri = mysql_query("SELECT * FROM servers ORDER by rand() LIMIT 10");
				while($server = mysql_fetch_array($kveri)) {
				$serverid = $server['id'];
				$r2++;
				$ip = $server['ip'];
				$port = $server['port'];
				$hostname = $server['hostname'];
				  if(strlen($hostname) > 40){ 
			          $hostname = substr($hostname,0,40); 
			          $hostname .= "..."; 
			     }

			?>
		<div class="boxserver">
			<?php echo $r2;?>. <img src="/img/igre/<?php echo $server['game']; ?>.gif" style="width:10px; height:10px;"> <img src="/img/lokacije/<?php echo $server['drzava']; ?>.png" style="height:10px;"> <a href="/server_info/<?php echo "$ip:$port"; ?>"> <?php echo $hostname; ?></a> <br />
		</div>
			<?php }; ?>
		</div> <!-- RANDOM SERVERI KRAJ -->


		<div id="latest_servers">
			<div class="title_servers">
				Upravo dodati serveri
			</div>
			<?php 

				$kveri = mysql_query("SELECT * FROM servers ORDER by id DESC LIMIT 10");
				while($server = mysql_fetch_array($kveri)) {
				$serverid = $server['id'];
				$r3++;
				$ip = $server['ip'];
				$port = $server['port'];
				$hostname = $server['hostname'];
				  if(strlen($hostname) > 40){ 
			          $hostname = substr($hostname,0,40); 
			          $hostname .= "..."; 
			     }

			?>
		<div class="boxserver">
			<?php echo $r3;?>. <img src="/img/igre/<?php echo $server['game']; ?>.gif" style="width:10px; height:10px;"> <img src="/img/lokacije/<?php echo $server['drzava']; ?>.png" style="height:10px;"> <a href="/server_info/<?php echo "$ip:$port"; ?>"> <?php echo $hostname; ?></a> <br />
		</div>
			<?php }; ?>
		</div> <!-- LATEST SERVERI KRAJ -->








		<br /> <br />
		
		<footer>
			
			Copyright 2015 &copy DJOXIGameTracker v1 <br />
			Kodirao: <a href="https://www.facebook.com/pages/Djordje-Radovanovic-Djoxi/285936344941972?ref=bookmarks">Djordje Radovanovic</a>
			
		</footer>
				
</div> <!-- OMOT -- >			
</div> <!--  BB KRAJ -->

</body>
</html>

<!-- POPUP PROZORI :D -->

				<div class="popup" data-popup="login">
				<div class="popup-inner">
					<div class="popup-title"><center> Ulogujte se </center></div>				
					<center>
						<form action="/login" method="POST">
						<input type="text" name="username" class="djoxi" placeholder="Username..."></input><br /> <br />
						<input type="password" name="password" class="djoxi" placeholder="Password..."></input> <br /> <br />
						
						<input type="submit" name="login" class="login_btn" value="LOGIN"></input>
						
						</form>
					</center>
					<a class="popup-close" data-popup-close="login" href="#">x</a>
					</div>
				</div>	

				<br /> <br /> <br />

				<div class="popup" data-popup="registracija">
				<div class="popup-inner1">
					<div class="popup-title"><center> Registrujte se </center></div>				
					<center>


					<?php 

					if(isset($_POST['register'])) {
 
					$username = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['username'])));
					$password = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['password'])));
					$email = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['email'])));
					$ime = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['ime'])));
					$prezime = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['prezime'])));
					$drzava = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['drzava'])));				        
				        if(strlen($username) > 20 || strlen($username) < 4){
				        $_SESSION['error'] = "Username je prekratak!";
						header("Location:index.php");
				        die();
				        }
				 
					$kveri = mysql_query("SELECT * FROM users WHERE username='$username'");
					if (mysql_num_rows($kveri)>0) {
					    $_SESSION['error'] = "Username je u upotrebi!";
						header("Location:index.php");
						die();
					}
					$kveri = mysql_query("SELECT * FROM users WHERE email='$email'");
					if (mysql_num_rows($kveri)>0) {
						$_SESSION['error'] = "Email je u upotrebi!";
						header("Location:index.php");
						die();
					}
					
					if ($password == $password) {
						$cpass = md5($password);
						$sql = "INSERT INTO users (username,ime,prezime,password,email,drzava,active,avatar) VALUES ('$username','$ime','$prezime','$cpass','$email','$drzava','1','nemaslike.png')";
						//echo $sql;
						mysql_query($sql);
						$_SESSION['ok'] = "Uspesna registracija!";
						header("location:index.php");
					} else {
						$_SESSION['error'] = "Greska";
						header("Location:index.php");
						die();
					}

				}


					?>


						<form action="" method="POST">

						<input type="text" name="ime" class="djoxi" placeholder="Ime..."></input><br /> <br />
						<input type="text" name="prezime" class="djoxi" placeholder="Prezime..."></input><br /> <br />	
						<input type="email" name="email" class="djoxi" placeholder="Email..."></input><br /> <br />						
						<input type="text" name="username" class="djoxi" placeholder="Username..."></input><br /> <br />
						<input type="password" name="password" class="djoxi" placeholder="Password..."></input> <br /> <br />
						<select type="text" name="drzava" class="djoxi_select">
							<option value="RS">Srbija</option>
							<option value="BA">Bosna i Hercegovina</option>
							<option value="ME">Crna Gora</option>
							<option value="MK">Makedonija</option>
						</select> <br /> <br />
						<input type="submit" name="register" class="login_btn" value="REGISTER"></input>
						
						</form>
					</center>
					<a class="popup-close" data-popup-close="registracija" href="#">x</a>
					</div>
				</div>		



				<div class="popup" data-popup="podesavanje">
				<div class="popup-inner2">
					<div class="popup-title"><center> Podesavanje naloga </center></div>				
					<center>
						<?php 

							if(isset($_POST['sacuvaj'])) {


								$ime = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['ime'])));
								$prezime = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['prezime'])));
								$email = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['email'])));																
								$sql = "UPDATE users SET ime='$ime',prezime='$prezime',email='$email' WHERE user_id='$_SESSION[user_id]'";
								$kveri = mysql_query($sql);

								if(!$sql) {

									$_SESSION['error'] = "Doslo je do greske!";
									header("Location:/index.php");


								} else {

									$_SESSION['ok'] = "Uspesno!";
									header("Location:/index.php");
								}
 
							}

						?>

						<form action="" method="POST">
						<label>Username:</label> <br />
						<input type="text" name="username" disabled class="djoxi" value="<?php echo $uinfo['username']; ?>"></input><br /> <br />

						<label>Ime:</label> <br />
						<input type="text" name="ime" class="djoxi" required="required" value="<?php echo $uinfo['ime']; ?>" placeholder="Ime..."></input><br /> <br />

						<label>Prezime:</label> <br />
						<input type="text" name="prezime" class="djoxi" required="required" value="<?php echo $uinfo['prezime']; ?>" placeholder="Prezime..."></input><br /> <br />

						<label>Email:</label> <br />
						<input type="email" name="email" class="djoxi" required="required" value="<?php echo $uinfo['email']; ?>" placeholder="Email..."></input><br /> <br />

						<input type="submit" name="sacuvaj" class="login_btn" value="SACUVAJ"></input>
						</form>
					</center>
					<a class="popup-close" data-popup-close="podesavanje" href="#">x</a>
					</div>
				</div>								



				<div class="popup" data-popup="novi_pw">
				<div class="popup-inner">
					<div class="popup-title"><center> Promena passworda </center></div>				
					<center>
						<?php 

							if(isset($_POST['izmeni'])) {


								$password = htmlspecialchars(mysql_real_escape_string(addslashes($_POST['novi_pw'])));	
								$novi_pw = md5($password);														
								$sql = "UPDATE users SET password='$novi_pw' WHERE user_id='$_SESSION[user_id]'";
								$kveri = mysql_query($sql);

								if(!$sql) {

									$_SESSION['error'] = "Doslo je do greske!";
									header("Location:/index.php");


								} else {

									$_SESSION['ok'] = "Uspesno!";
									header("Location:/index.php");
								}
 
							}

						?>

						<form action="" method="POST">
						<label>Novi password:</label> <br />
						<input type="password" name="novi_pw" required="required" class="djoxi" placeholder="Upisite novi password..."></input><br /> <br />
						<input type="submit" name="izmeni" class="login_btn" value="IZMENI"></input>
						</form>
					</center>
					<a class="popup-close" data-popup-close="novi_pw" href="#">x</a>
					</div>
				</div>								





				<div class="popup" data-popup="cavatar">
				<div class="popup-inner1">
					<div class="popup-title"><center> Promeni Avatar </center></div>				
					<center>
										
					
						<img src="/avatari/<?php echo $uinfo['avatar']; ?>" style="width:200px; height:200px;">
	
						 <form action="/process.php?task=upload_avatar" method="POST" enctype="multipart/form-data">
						 <input type="file" name="file" style="width:150px;" id="file"><br/><br/>
						 <button class="login_btn">Upload</button>
						 </form>						
						
					</center>
					<a class="popup-close" data-popup-close="cavatar" href="#">x</a>
					</div>
				</div>								



