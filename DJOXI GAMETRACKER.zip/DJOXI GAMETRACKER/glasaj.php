<?php
defined("access") or die("Direktan pristup odbijen!");
	$id = $_GET['id'];	



	$info = mysql_fetch_array(mysql_query("SELECT * FROM servers WHERE id='$id'"),0);
	
	$ip 	= $info['ip'];
	$port 	= $info['port'];

	if(logged_in () == false) {
		
		die("<script> alert('Morate se ulogovati!'); document.location.href='/server_info/$ip:$port'; </script>");
	
		
	} else {



	if($id == "") {
		
		die("<script> alert('Server ne postoji!'); document.location.href='/serveri'; </script>");
		
	}
	
	if(!$info) {
		
		die("<script> alert('Server ne postoji!'); document.location.href='/serveri'; </script>");	
		
	}
	

					
	$provera_korisnika = mysql_num_rows(mysql_query("SELECT id FROM glasovi WHERE user_id='$_SESSION[user_id]' AND server='$id'"));
	if($provera_korisnika < 1) {
		
		
		$glas = "INSERT into glasovi(user_id,server,glas) VALUES('$_SESSION[user_id]','$id','1')";
		$kveri_glas = mysql_query($glas);
		
		if(!$glas) {
			
		die("<script> alert('Dogodila se greska!'); document.location.href='/server_info/$ip:$port'; </script>");				
			
		} else {
		
		$glas = mysql_result(mysql_query("SELECT glasovi FROM servers WHERE id='$id'"));
		$novi_glas = $glas +1;
		$user_id = $_SESSION['user_id'];
		$vreme = time();
		$datum = date('d.m.Y');		
		mysql_query("UPDATE `servers` SET `glasovi` = glasovi +1 WHERE `id` = $id");

		die("<script> alert('Uspesno ste glasali!'); document.location.href='/server_info/$ip:$port'; </script>");					
		
			
		}
		
		
	} else {
		
	die("<script> alert('Vec ste glasali za ovaj server!'); document.location.href='/server_info/$ip:$port'; </script>");					
		
		
	}
	
			
	} // LOGIN PROvERA :D 


				
	


?>




		 
		 
