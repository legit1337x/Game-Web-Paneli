<!-- PRETRAGA -->

		<h3>Rezultati pretrage</h3> 

		<?php
			
			if(isset($_POST['trazi'])) {
				
				$ime_servera = $_POST['ime_servera'];
				$sql = "SELECT * FROM servers WHERE hostname LIKE '%{$ime_servera}%'";


				$kveri = mysql_query($sql);
 				
				while($red=mysql_fetch_assoc($kveri)) {
				// SADRZAJ
				$ime_servera1 = $red['hostname'];
				  if(strlen($ime_servera1) > 30){ 
						  $ime_servera1 = substr($ime_servera1,0,150); 
						  $ime_servera1 .= "..."; 
					 }					
				$vid = $red['id'];
				

			?>
			
	   		<?php echo $ime_servera1; ?> <br />
	
			
			<?php }} mysql_free_result($kveri); ?>
			
			
			
			

		
		
<!-- PRETRAGA KRAJ -->


