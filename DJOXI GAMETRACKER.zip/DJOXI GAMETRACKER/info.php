<?php 


include 'connect.php';




$server_query	= mysql_query("SELECT * FROM servers ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id					= $server_row['id'];
	$server_ip					= $server_row['ip'];
	$server_port				= $server_row['port'];
	$server_rank_pts			= $server_row['rank_pts'];

	
	
	try {
		$Query = new LiveStats($server_ip, $server_port);
		$info = $Query->GetServer();
	}
	catch (LSError $e) {}
	
	//Check status of the server
	if(empty($e)){ $status = 1; } else { $status = 0; }
	

	if($status == "1"){
		$num_players		= mysql_real_escape_string($info->PlayerCount);
		$max_players		= mysql_real_escape_string($info->MaxPlayers);
		
		$rank_pts			= $server_rank_pts + ($num_players/$max_players);

		$update_query		= mysql_query("UPDATE servers SET rank_pts='$rank_pts' WHERE id='$server_id'");
	} 
}// while kraj
