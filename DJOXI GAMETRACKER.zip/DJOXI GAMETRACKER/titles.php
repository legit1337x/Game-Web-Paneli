<?php

error_reporting(0);

$bigTitle  = $settings['title'];
$pageTitle = $_GET['page'];


if($pageTitle == "") {
	
	$pageTitle = "Home";
	
} 



$pageTitle = $bigTitle . " &raquo; " . $pageTitle;
?>