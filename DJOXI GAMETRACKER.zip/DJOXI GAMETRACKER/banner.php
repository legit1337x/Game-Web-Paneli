<?php
        session_start();
        include('connect.php'); 
        include('q.php');       
    
        $ip_port  = explode(":", $_GET['ip']);
        $ip     = $ip_port[0];
        $port   = $ip_port[1];
    
        $info = mysql_fetch_array(mysql_query("SELECT * FROM servers WHERE ip='$ip' AND port='$port'"));



        try {
            $Query = new LiveStats($ip, $port);
            $info2 = $Query->GetServer();
        }
        catch (LSError $e) {}
        
        //Check status of the server
        if(empty($e)){ $status = 1; } else { $status = 0; }
                
        $cache = trim($cache);
        $datum = date('d');



        if($status == "1") {

            $name = $info2->Hostname;
            $name = substr($name,0,20); 
            $name .= "..."; 

            $mapa = $info2->Map;
        }

        else {
    
        $name = $info['hostname'];

        if(strlen($name) > 40){ 
            $name = substr($name,0,20); 
            $name .= "..."; 

        $mapa = $info['mapa']; 


        }         
        


        }
        
        $igra = $info['game'];

        $status = $info['status'];
        if($status == "1"){
          $status = "Online";
        } else {
          $status = "Offline";
        }
        
        $game = $info['game'];
        if($game = "cstrike"){
           $game = "Counter-Strike 1.6";
        } else {}
        

        

        if($ip_port == ""){
         $_SESSION['error'] = "Server banner doesn't exist , add server to get banner";
         header("location:/index.php");
         die();
        } else {

        $server_max_players = $info['max_igraca'];
        $server_playercount = $info['broj_igraca'];
        $chart_x_fields     = $info['cache_time'];
        $chart_x_replace    = "0,2,4,6,8,10,12,14,16,18,20,22,24";
        $chart_x_max        = $server_max_players;
        $chart_data         = $server_playercount;
        
        $chart_img          = imagecreatefrompng("http://chart.apis.google.com/chart?chf=bg,s,67676700&chxp=&chs=130x50&cht=lc&chco=0c77b0&chds=0,$chart_x_max&chd=t:$chart_data&chdlp=b&chls=1&chm=B,004466,0,0,0,5");



        

        header('Content-type: image/jpeg');

        $im = imagecreatefromjpeg('img/banneri/cstrike/csbanner.jpg');
        imagecopy($im, $chart_img, 360, 30, 0, 0, 130, 50);
        // get the image size
        $w = imagesx($im);
        $h = imagesy($im);
        $white = imagecolorallocate($im, 255, 255, 255);
        $font = dirname(__FILE__) . '/fonts/arial.ttf';


// place some text (top, left)
            
        imagettftext($im, 8, 0, 110, 40, $white, 'fonts/arial.ttf', "$name");
        imagettftext($im, 8, 0, 110, 73, $white, 'fonts/arial.ttf', "$ip:$port");
        imagettftext($im, 8, 0, 110, 106, $white, 'fonts/arial.ttf', "$mapa");  
        imagettftext($im, 8, 0, 210, 106, $white, 'fonts/arial.ttf', "$info[broj_igraca]/$info[max_igraca]");
        imagettftext($im, 8, 0, 290, 106, $white, 'fonts/arial.ttf', "#$info[rank]");
        if($info['status'] == "1"){
        imagettftext($im, 8, 0, 280, 71, $white, 'fonts/arial.ttf', "$status");      
        } else {
        imagettftext($im, 8, 0, 280, 71, $white, 'fonts/arial.ttf', "$status");        
        }      
    imageJpeg($im);
    imagedestroy($im);

}
?>

