-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 25, 2015 at 05:50 PM
-- Server version: 5.5.42-cll
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `djoxi_gt`
--

-- --------------------------------------------------------

--
-- Table structure for table `banovi`
--

CREATE TABLE IF NOT EXISTS `banovi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `glasovi`
--

CREATE TABLE IF NOT EXISTS `glasovi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `server` int(11) NOT NULL,
  `glas` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE IF NOT EXISTS `guests` (
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` varchar(65) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`ip`, `last_activity`) VALUES
('178.149.59.37', '1440514219');

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE IF NOT EXISTS `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(222) COLLATE utf8_unicode_ci NOT NULL,
  `mod` varchar(222) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `vlasnik` int(11) NOT NULL,
  `forum` varchar(222) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `game` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `drzava` varchar(222) COLLATE utf8_unicode_ci NOT NULL,
  `mapa` varchar(222) COLLATE utf8_unicode_ci NOT NULL,
  `rank` int(11) NOT NULL,
  `port` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `max_igraca` int(11) NOT NULL,
  `broj_igraca` int(11) NOT NULL,
  `glasovi` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `cache` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `cache_time` text COLLATE utf8_unicode_ci NOT NULL,
  `ban` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=92 ;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `hostname`, `mod`, `user_id`, `vlasnik`, `forum`, `ip`, `game`, `drzava`, `mapa`, `rank`, `port`, `max_igraca`, `broj_igraca`, `glasovi`, `status`, `cache`, `cache_time`, `ban`) VALUES
(83, 'faNtasy Gaming Classic [DeathMatch]Â® by E-Trail.eu', 'DeathMatch', 2, 0, '', '87.98.241.203', 'cstrike', 'RS', 'de_dust2', 1, '27018', 32, 30, 0, 1, '', '1440492102', 0),
(88, 'Extra Classic [Russia]', 'Public', 1, 0, '', '77.220.180.73', 'cstrike', 'RS', 'de_mirage', 2, '27015', 32, 32, 0, 1, '', '1440491160', 0),
(85, 'Djoxi GameTracker\r', 'Public', 1, 0, '', '82.211.44.147', 'cstrike', 'RS', 'de_dust2', 3, '27099', 32, 0, 0, 0, '', '1440513364', 0),
(89, '.:: Cyber GaminG ::.', 'Public', 1, 0, '', '193.192.59.19', 'cstrike', 'MK', 'de_dust2', 4, '27031', 32, 32, 0, 1, '', '1440511582', 0),
(90, 'Global Gaming Nis', 'Public', 1, 0, '', '193.104.68.49', 'cstrike', 'RS', 'de_aztec_0', 5, '27040', 32, 31, 0, 1, '', '1440491327', 0),
(91, 'FLa7a by kgb-hosting.com', 'Public', 1, 0, '', '193.192.58.82', 'cstrike', 'RS', 'de_dust2', 6, '27032', 12, 0, 0, 1, '', '1440492624', 0);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL DEFAULT '1',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Comples Servers List',
  `facebook` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  `twitter` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  `contact_email` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pagination` int(11) NOT NULL DEFAULT '15',
  `register` int(11) NOT NULL DEFAULT '1',
  `server_cache` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '600',
  `show_offline_servers` int(11) NOT NULL DEFAULT '0',
  `email_confirmation` int(11) NOT NULL DEFAULT '1',
  `server_confirmation` int(11) NOT NULL DEFAULT '1',
  `advertise_top` varchar(2555) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  `advertise_bottom` varchar(2555) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `facebook`, `twitter`, `contact_email`, `pagination`, `register`, `server_cache`, `show_offline_servers`, `email_confirmation`, `server_confirmation`, `advertise_top`, `advertise_bottom`) VALUES
(1, 'DJOXI', 'false', 'false', 'ContactEmail', 15, 1, '600', 0, 0, 0, 'false', 'false');

-- --------------------------------------------------------

--
-- Table structure for table `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(222) NOT NULL,
  `komentar` longtext NOT NULL,
  `server` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(222) NOT NULL,
  `prezime` varchar(222) NOT NULL,
  `drzava` varchar(222) NOT NULL,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email_code` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(65) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `type` int(1) NOT NULL DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `date` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` varchar(65) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `ime`, `prezime`, `drzava`, `username`, `password`, `email`, `email_code`, `avatar`, `active`, `type`, `ip`, `date`, `last_activity`) VALUES
(1, 'Djordje', 'Radovanovic', 'RS', 'Djoxi', 'ec3cba92586b52a8c035752494c082a7', 'djordjeradovanovicvrba@gmail.com', '', '1440450054.png', 1, 1, '0.0.0.0', 'beginen of time...', '1440514215'),
(2, 'Demo', 'Demo', 'BA', 'Demo', '098f6bcd4621d373cade4e832627b4f6', 'demo@demo.com', '', 'nemaslike.png', 1, 0, '0.0.0.0', '', '1440492144'),
(3, 'Stefan', 'Masovic', 'ME', 'Maske.', '319e1c3d8b2a1f35204a238423a8b1d0', 'stefanamsovic@maske.com', '', 'nemaslike.png', 1, 0, '0.0.0.0', '', '1440354848'),
(4, 'Marko', 'Kostoski', 'MK', 'LoadingFX', '57b2de3b6ade33f407a9c86a30ddb336', 'marko.kostoski9@gmail.com', '', 'nemaslike.png', 1, 0, '0.0.0.0', '', '1440453040');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
