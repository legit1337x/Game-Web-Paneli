<?php 
	
	$id = $_GET['user_id'];

	$info = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE user_id='$id'"));

	if(!$info) {

		$_SESSION['error'] = "Korisnik ne postoji!";
		header("Location:/index.php");
	}

	if($id == "") {

		$_SESSION['error'] = "Korisnik ne postoji!";
		header("Location:/index.php");

	}

	$status = $info['active'];
	if($status == "1") {
		$status = "Aktivan!";
	} else 
	if($status == "0") {

		$status = "Neaktivan!";
	}

	$rank = $info['type'];
	if($rank == "0") {

		$rank = "Korisnik";
	} else {
	if($rank == "1") {

		$rank = "Administrator";
	}
	}

?>
<div id="srvuser">

	Serveri korisnika <strong><?php echo $info['username']; ?></strong> <hr />

	<?php 

	$brs = mysql_num_rows(mysql_query("SELECT id FROM servers WHERE user_id='$info[user_id]'"));
	if($brs < 1) {

		echo "Nema servera...";

	}
	else {

		$sql = "SELECT * FROM servers WHERE user_id='$info[user_id]' ORDER by rank ASC";
		$kveri = mysql_query($sql);
		while($red = mysql_fetch_array($kveri)) {

		$hostname = $red['hostname'];
  		if(strlen($hostname) > 30){ 
		$hostname = substr($hostname,0,30); 
		$hostname .= "..."; 
		} 	

	?>

	<?php echo $red['rank']; ?>. <img src="/img/igre/<?php echo $red['game']; ?>.gif" style="width:10px; height:10px;"> <img src="/img/lokacije/<?php echo $red['drzava']; ?>.png" style="height:10px;"> <a href="/server_info/<?php echo "$red[ip]:$red[port]"; ?>"><?php echo $hostname; ?></a> <hr />

	<?php }}; ?>



</div>
<br /> <br />

